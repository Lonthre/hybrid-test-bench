#%%
import zipfile
from setuptools import setup
from setuptools import find_packages
from setuptools import find_namespace_packages
from setuptools import Extension
from generate_license import  *
import os

#%% Input section

package_name = 'yafem'
description  = 'Yet Another Finite Element Method (YAFEM) Package'
version      = '0.2.6'
requirements = False

#%% save old version of yafem
if not os.path.exists('releases'):
    os.makedirs('releases')

dist_folder = 'dist'
releases_folder = 'releases'

# Get .gz
dist_tar_files = [f for f in os.listdir(dist_folder) if f.endswith('.gz')]

for i, tar_file in enumerate(dist_tar_files):
    version_number = tar_file[len('yafem-'):-len('.tar.gz')]

    # Filter files that contain the version number
    dist_files = [f for f in os.listdir(dist_folder) if version_number in f]
    zip_filename = os.path.join(releases_folder, f'yafem_{version_number}.zip')

    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file in dist_files:
                file_path = os.path.join(dist_folder, file)
                zipf.write(file_path, arcname=file)
                try:
                    os.remove(file_path)
                except Exception as e:
                    print(f"Error deleting {file_path}: {e}")

#%% Load requirements

if requirements == True:
    with open('requirements.txt') as f:
        required = f.read().splitlines()
else:
    required = ('numpy',
                'scipy',
                'jax',
                'jaxlib',
                'matplotlib',
                )

# Generating license file of the "required"
generate_license(required)

#%% Exclude redundant files

# all files in the package_name path
yafem_files = os.listdir(package_name + '\\elem')

# dev files
yafem_dev_files = [s for s in yafem_files if "_dev" in s]

# file to generate lamdified functions
yafem_lambdify_saver = [s for s in yafem_files if "lambdify_saver" in s]

# concatinated files to be ignored when packing
exclude_files = yafem_dev_files + yafem_lambdify_saver + ["testing", "testing.*"]

#%% Setup

setup(
    setup_requires=['wheel'],
    name = package_name,
    version = version,
    description = description,
    long_description= open('readme_package_description.md').read() + \
                      ' \n# Change log of version ' + version + ': \n\n' + \
                      open('readme_change_log\\readme_changes_' + version + '.md').read(),             
    install_requires = required,
    packages = find_packages(exclude = exclude_files),
    package_data={'': ['LICENSE.md']},
    package_dir={"yafem": "yafem"},
     )

#%% Creating a requirements file

dist_files = os.listdir('dist')
yafem_wheel = [s for s in dist_files if ".whl" in s and version in s]

with open('dist\\requirements.txt', 'w') as f:
    f.write(yafem_wheel[0] + '\n')

with open('dist\\requirements.txt', 'a') as f:
    f.write('sympy' + '\n'
            'numpy' + '\n'
            'scipy' + '\n'
            'pandas' + '\n'
            'jax' + '\n'
            'jaxlib' + '\n'
            'matplotlib' + '\n'
            'ipykernel' + '\n'
            'mkdocs-material' + '\n'
            'pipdeptree' + '\n'
            'gmsh' + '\n'
            'raschii' + '\n'
            )