# Third-Party Licenses

### numpy
- Version: 2.2.2
- License: Copyright (c) 2005-2024, NumPy Developers.

### scipy
- Version: 1.15.1
- License: Copyright (c) 2001-2002 Enthought, Inc. 2003-2024, SciPy Developers.

### jax
- Version: 0.5.0
- License: Apache-2.0

### jaxlib
- Version: 0.5.0
- License: Apache-2.0

### matplotlib
- Version: 3.10.0
- License: License agreement for matplotlib versions 1.3.0 and later

