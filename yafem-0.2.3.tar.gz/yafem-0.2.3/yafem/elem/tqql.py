import numpy as np
from yafem.nodes import nodes
from yafem.elem.core_elem import core_elem
from yafem.tqql_func import *

#%% element_MCK class
class tqql(core_elem):

    # superclass constructor
    super().__init__(my_nodes,pars)

    # link the nodes to the element
    self.my_nodes = my_nodes

    self.ctrv_vec = my_nodes.nodal_coords[:4,:]

    # extract parameters and assign default values
    self.extract_pars(pars)

    r3 = 1 /np.sqrt(3)
    ap = 0.5 - r3

    cx = np.array([0.5 - r3, 0.5+r3, ap, 1.0-ap, 0, 0])
    cy = np.array([0 , 0, 1.0 - ap, ap, 0.5+r3, 0.5-r3])
    a  = np.sqrt(2)/2

    # Material properties (Constant over the domain)
    aux1 = self.h * self.E / (1-self.nu**2)
    aux2 = self.nu * aux1
    aux3 = self.h * self.E / 2 / (1+self.nu)
    aux4 = (5/6) * self.h * self.E / 2 / (1+self.nu)
    
    self.Dm = np.array([[aux1, aux2,    0],
                        [aux2, aux1,    0],
                        [   0,    0, aux3]])

    self.Ds = np.array([[aux4, 0],[0, aux4]])
    self.Db = Dm * (self.h**2 / 12)

    # transformation matrix
    self.T = np.array([[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                       [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                       [0, 0, 0, 0,-a, a, 0, 0, 0, 0, 0, 0],
                       [0, 0, 0, 0, 0, 0,-a, a, 0, 0, 0, 0],
                       [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
                       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]])

    # shear strain field
    self.P = np.array([[ 1,   cx[0],   cy[0], 0,       0,      0 ],
                       [ 1,   cx[1],   cy[1], 0,       0,      0 ],
                       [-a,-a*cx[2],-a*cy[2], a, a*cx[2], a*cy[2]],
                       [-a,-a*cx[3],-a*cy[3], a, a*cx[3], a*cy[3]],
                       [ 0,       0,       0, 1,   cx[4],   cy[4]],
                       [ 0,       0,       0, 1,   cx[5],   cy[5]]])

#%%

    # Test of evaluating variables
    self.xjacm_all = []
    self.xjaci_all = []
    self.Bb_all = []
    self.Bm_all = []
    self.Bs_all = []
    self.Ks_all = []
    self.Kb_all = []
    self.Km_all = []
    self.B_bar_all = []

    self.Kg = np.zeros((30, 30))
    self.M = np.zeros((30, 30))

    for i in range(len(self.gp)):
        L2 = self.gp[i, 0]
        L3 = self.gp[i, 1]
        wg = self.w[i]

        self.area = area(L2, L3, self.x[0], self.x[1], self.x[2], self.x[3], self.x[4], self.x[5],
                                 self.y[0], self.y[1], self.y[2], self.y[3], self.y[4], self.y[5])

        xjacm_eval = xjacm(L2, L3, self.x[0], self.x[1], self.x[2], self.x[3], self.x[4], self.x[5],
                                   self.y[0], self.y[1], self.y[2], self.y[3], self.y[4], self.y[5])

        xjaci_eval = np.linalg.inv(xjacm_eval)

        Bb_eval = Bb_mat(L2, L3, xjaci_eval[0, 0], xjaci_eval[0, 1], xjaci_eval[1, 0], xjaci_eval[1, 1])
        Bm_eval = Bm_mat(L2, L3, self.T[0, 0], self.T[0, 1], self.T[0, 2],
                                 self.T[1, 0], self.T[1, 1], self.T[1, 2],
                                 self.T[2, 0], self.T[2, 1], self.T[2, 2],
                                 xjaci_eval[0, 0], xjaci_eval[0, 1], xjaci_eval[1, 0], xjaci_eval[1, 1])

        xgs = L2
        ygs = L3

        A = np.array([[1, xgs, ygs, 0, 0  , 0   ],
                    [0, 0  , 0  , 1, xgs, ygs ]])

        c = np.zeros((12, 12))
        B_bar = np.empty((0, 18))  # Initialize B_bar as an empty matrix with 18 columns

        for j in range(6):
            L2_local = cx[j]
            L3_local = cy[j]

            N = phi(L2_local, L3_local)
            dxNloc = dxNloc(L2_local, L3_local)
            dyNloc = dyNloc(L2_local, L3_local)

            xjacm = xjacm(L2_local, L3_local, self.x[0], self.x[1], self.x[2], self.x[3], self.x[4], self.x[5],
                                              self.y[0], self.y[1], self.y[2], self.y[3], self.y[4], self.y[5])
          
            xjacip = np.linalg.inv(xjacm)

            dxN = dxN(L2_local, L3_local, xjacip[0, 0], xjacip[0, 1], xjacip[1, 0], xjacip[1, 1])
            dyN = dyN(L2_local, L3_local, xjacip[0, 0], xjacip[0, 1], xjacip[1, 0], xjacip[1, 1])

            jpos = slice(j * 2, j * 2 + 2)
            c[jpos, jpos] = xjacm

            # Create Bmat_s_d matrices
            Bmat_s_d = [create_Bmat_s(dxN[ii], dyN[ii], N[ii]) for ii in range(6)]
            Bmat_s = [np.hstack(Bmat_s_d[ii]) for ii in range(6)]
            Bs_mat = np.hstack(Bmat_s)

            # Append to B_bar
            B_bar = np.vstack([B_bar, Bs_mat])

        self.B_bar_all.append(B_bar)

        bmat_ss = np.dot(np.dot(np.dot(np.dot(xjaci_eval, A), np.linalg.inv(P_mat)), T_mat), c).dot(B_bar)

        bmat_s1 = np.array([[0, 0, bmat_ss[0, 0]],
                            [0, 0, bmat_ss[1, 0]]])

        bmat_s2 = np.array([[0, 0, bmat_ss[0, 3]],
                            [0, 0, bmat_ss[1, 3]]])

        bmat_s3 = np.array([[0, 0, bmat_ss[0, 6]],
                            [0, 0, bmat_ss[1, 6]]])
                            
        bmat_s4 = np.array([[0, 0, bmat_ss[0, 9]],
                            [0, 0, bmat_ss[1, 9]]])

        bmat_s5 = np.array([[0, 0, bmat_ss[0, 12]],
                            [0, 0, bmat_ss[1, 12]]])

        bmat_s6 = np.array([[0, 0, bmat_ss[0, 15]],
                            [0, 0, bmat_ss[1, 15]]])

        bmat_s1 = np.hstack([np.dot(bmat_s1, self.T), bmat_ss[:, 1:3]])
        bmat_s2 = np.hstack([np.dot(bmat_s2, self.T), bmat_ss[:, 4:6]])
        bmat_s3 = np.hstack([np.dot(bmat_s3, self.T), bmat_ss[:, 7:9]])
        bmat_s4 = np.hstack([np.dot(bmat_s4, self.T), bmat_ss[:, 10:12]])
        bmat_s5 = np.hstack([np.dot(bmat_s5, self.T), bmat_ss[:, 13:15]])
        bmat_s6 = np.hstack([np.dot(bmat_s6, self.T), bmat_ss[:, 16:18]])

        Bs_eval = np.hstack([bmat_s1, bmat_s2, bmat_s3, bmat_s4, bmat_s5, bmat_s6])

        Ks = np.dot(np.dot(Bs_eval.T, Ds), Bs_eval) * self.area * wg
        Kb = np.dot(np.dot(Bb_eval.T, Db), Bb_eval) * self.area * wg
        Km = np.dot(np.dot(Bm_eval.T, Dm), Bm_eval) * self.area * wg

        N = N_mat(L2, L3)
        self.M += np.dot(np.dot(N.T, self.rho * np.diag([self.h, self.h, self.h, self.h**3 / 12, -self.h**3 / 12])), N) * self.area * wg
        self.Kg += Ks + Kb + Km

        self.xjacm_all.append(xjacm_eval)
        self.xjaci_all.append(xjaci_eval)
        self.Bb_all.append(Bb_eval)
        self.Bm_all.append(Bm_eval)
        self.Bs_all.append(Bs_eval)
        self.Ks_all.append(Ks)
        self.Kb_all.append(Kb)
        self.Km_all.append(Km)

    self.K = self.Kg
    self.C = np.zeros_like(self.Kg)

    #%% extract parameters and assign default values
    def extract_pars(self,pars):

        self.E   = pars.get('E', 210e9) # young's modulus
        self.nu  = pars.get('nu', 0.3) # poisson's ratio
        self.rho = pars.get('rho', 7850) # material density
        self.h   = pars.get('h', 5e-3) # element thickness
        self.nodal_labels = pars.get("nodal_labels", [1, 2])
        self.nodal_coords = self.my_nodes.find_coords(self.nodal_labels) # extract nodal coordinates
        self.gauss_order  = pars.get("gauss_order", 2)  # number of Gauss points
        self.type    = pars.get("type", "ps")  # type of analysis (ps = plane stress, pe = plane strain, ax = axisymmetric)

        # temperature controlled dofs
        self.dofs_q = pars.get('dofs_q', np.zeros((0, 2), dtype=np.int32)).astype(np.int32)

    def rotation_matrix(self, cxyz):
        v12 = np.zeros(3)
        v13 = v12.copy()
        vxe = v12.copy()
        vye = v12.copy()
        vze = v12.copy()

        v12[0] = cxyz[1, 0] - cxyz[0, 0]
        v12[1] = cxyz[1, 1] - cxyz[0, 1]
        v12[2] = cxyz[1, 2] - cxyz[0, 2]

        v13[0] = cxyz[2, 0] - cxyz[0, 0]
        v13[1] = cxyz[2, 1] - cxyz[0, 1]
        v13[2] = cxyz[2, 2] - cxyz[0, 2]

        vze[0] = v12[1] * v13[2] - v12[2] * v13[1]
        vze[1] = v12[2] * v13[0] - v12[0] * v13[2]
        vze[2] = v12[0] * v13[1] - v12[1] * v13[0]

        dz = np.sqrt(vze[0]**2 + vze[1]**2 + vze[2]**2)

        vze /= dz

        vxe[0] =  1 / np.sqrt(1 + (vze[0] / vze[2]) ** 2)
        vxe[2] = -1 / np.sqrt(1 + (vze[2] / vze[0]) ** 2)

        dd = vxe[0] * vze[0] + vxe[2] * vze[2]
        if abs(dd) > 1e-8:
            vxe[2] = -vxe[2]

        if vze[2] == 0 and vze[0] == 0:
            vxe[0] = 1
            vxe[1] = 0
            vxe[2] = 0

        vye[0] = vze[1] * vxe[2] - vxe[1] * vze[2]
        vye[1] = vze[2] * vxe[0] - vxe[2] * vze[0]
        vye[2] = vze[0] * vxe[1] - vxe[0] * vze[1]

        dy = np.sqrt(vye[0]**2 + vye[1]**2 + vye[2]**2)
        vye /= dy

        if vye[1] < 0:
            vye = -vye
            vxe = -vxe

        Te = np.array([vxe, vye, vze])
        return Te

    #%% gauss-legrendre quadrature
    def gl_quadrature_tri(self, order):
        if order == 1:
            x = np.array([[1, 1]]) * 1/3
            w = np.array([1.0])

        elif order == 2:
            x = np.array([[1/6, 1/6], [2/3, 1/6], [1/6, 2/3]])
            w = np.array([1, 1, 1]) * 1/3

        elif order == 3:
            gamma_1 = -27/48
            gamma_2 =  25/48

            x = np.array([[1/3, 1/3], [0.6, 0.2], [0.2, 0.6], [0.2, 0.2]])
            w = np.array([gamma_1, gamma_2, gamma_2, gamma_2])

        elif order == 4:
            alpha_1 = 0.8168475730
            alpha_2 = 0.1081030182
            beta_1  = 0.0915762135
            beta_2  = 0.4459484909
            gamma_3 = 0.2199034874 / 2
            gamma_4 = 0.4467631794 / 2

            x = np.array([[beta_1,  beta_1], 
                          [alpha_1, beta_1], 
                          [beta_1, alpha_1], 
                          [alpha_2, beta_2], 
                          [beta_2, alpha_2], 
                          [beta_2,  beta_2]])

            w = np.array([gamma_3, gamma_3, gamma_3, gamma_4, gamma_4, gamma_4])
            
        else:
            raise ValueError("Unsupported order")
            
        return x, w

#%%

import numpy as np

class TQQL:
    def __init__(self, pars, my_nodes, nf):
        self.pars = pars
        self.my_nodes = my_nodes
        self.extract_pars()
        self.dofs = self.element_dofs(5)
        self.cxyz = self.nodal_coords[:, :3]

        # Extracting the corner coordinates of the triangle element
        ctrv_vec = np.array([self.cxyz[0, :3], self.cxyz[2, :3], self.cxyz[4, :3]]).T
        self.ctrv = np.vstack(ctrv_vec)

        # Defining the rotation matrix based on the corner nodes
        self.T = self.rotation_matrix(self.ctrv)

        # Transform nodal coordinates to the local system
        self.ctxy = np.dot(self.cxyz, self.T.T)

        # Assume middle node
        self.ctxy[1, :2] = (self.ctxy[0, :2] + self.ctxy[2, :2]) / 2
        self.ctxy[3, :2] = (self.ctxy[2, :2] + self.ctxy[4, :2]) / 2
        self.ctxy[5, :2] = (self.ctxy[4, :2] + self.ctxy[0, :2]) / 2

        # Assume middle node (GMSH)
        # self.ctxy[3, :2] = (self.ctxy[0, :2] + self.ctxy[1, :2]) / 2
        # self.ctxy[4, :2] = (self.ctxy[1, :2] + self.ctxy[2, :2]) / 2
        # self.ctxy[5, :2] = (self.ctxy[2, :2] + self.ctxy[0, :2]) / 2

        # Element x and y coordinates
        self.x = self.ctxy[:, 0]
        self.y = self.ctxy[:, 1]
        self.xe = np.column_stack((self.x, self.y))

        # Defining the gauss points and the respective weights
        self.gp, self.w = self.gl_quadrature_tri(self.gauss_order)

        r3 = 1 / np.sqrt(3)
        ap = 0.5 - r3
        self.r3 = r3
        self.ap = ap

        self.cx = [0.5 - r3, 0.5 + r3, ap, 1.0 - ap, 0, 0]
        self.cy = [0, 0, 1.0 - ap, ap, 0.5 + r3, 0.5 - r3]

        aux1 = self.h * self.E / (1 - self.nu ** 2)
        aux2 = self.nu * aux1
        aux3 = self.h * self.E / 2 / (1 + self.nu)
        aux4 = (5 / 6) * self.h * self.E / 2 / (1 + self.nu)

        self.Dm = np.array([[aux1, aux2, 0], [aux2, aux1, 0], [0, 0, aux3]])
        self.Ds = np.array([[aux4, 0], [0, aux4]])
        self.Db = self.Dm * (self.h**2 / 12)

        self.T_mat = np.array([
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, -np.sqrt(2) / 2, np.sqrt(2) / 2, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, -np.sqrt(2) / 2, np.sqrt(2) / 2, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
        ])

        self.P_mat = np.array([
            [1, self.cx[0], self.cy[0], 0, 0, 0],
            [1, self.cx[1], self.cy[1], 0, 0, 0],
            [-np.sqrt(2) / 2, -np.sqrt(2) / 2 * self.cx[2], -np.sqrt(2) / 2 * self.cy[2], np.sqrt(2) / 2, np.sqrt(2) / 2 * self.cx[2], np.sqrt(2) / 2 * self.cy[2]],
            [-np.sqrt(2) / 2, -np.sqrt(2) / 2 * self.cx[3], -np.sqrt(2) / 2 * self.cy[3], np.sqrt(2) / 2, np.sqrt(2) / 2 * self.cx[3], np.sqrt(2) / 2 * self.cy[3]],
            [0, 0, 0, 1, self.cx[4], self.cy[4]],
            [0, 0, 0, 1, self.cx[5], self.cy[5]]
        ])

        self.xjacm_all = []
        self.xjaci_all = []
        self.Bb_all = []
        self.Bm_all = []
        self.Bs_all = []
        self.Ks_all = []
        self.Kb_all = []
        self.Km_all = []
        self.B_bar_all = []

        self.Kg = np.zeros((30, 30))
        self.M = np.zeros((30, 30))

        for i in range(len(self.gp)):
            L2 = self.gp[i, 0]
            L3 = self.gp[i, 1]
            wg = self.w[i]

            # Calculate area
            self.area = area(L2, L3, *self.x, *self.y)

            # Evaluate Jacobian matrix and its inverse
            xjacm_eval = xjacm(L2, L3, *self.x, *self.y)
            xjaci_eval = np.linalg.inv(xjacm_eval)

            # Evaluate Bb and Bm matrices
            Bb_eval = Bb_mat(L2, L3, xjaci_eval[0, 0], xjaci_eval[0, 1], xjaci_eval[1, 0], xjaci_eval[1, 1])
            Bm_eval = Bm_mat(L2, L3, *self.T.flatten(), xjaci_eval[0, 0], xjaci_eval[0, 1], xjaci_eval[1, 0], xjaci_eval[1, 1])

            xgs = L2
            ygs = L3

            A = np.array([
                [1, xgs, ygs, 0, 0, 0],
                [0, 0, 0, 1, xgs, ygs]
            ])

            c = np.zeros((12, 12))
            B_bar = np.empty((0, 18))

            for j in range(6):
                L2 = self.cx[j]
                L3 = self.cy[j]

                N = phi(L2, L3)
                dxNloc = dxNloc(L2, L3)
                dyNloc = dyNloc(L2, L3)

                xjacm = xjacm(L2, L3, *self.x, *self.y)
                xjacip = np.linalg.inv(xjacm)

                dxN = dxN(L2, L3, xjacip[0, 0], xjacip[0, 1], xjacip[1, 0], xjacip[1, 1])
                dyN = dyN(L2, L3, xjacip[0, 0], xjacip[0, 1], xjacip[1, 0], xjacip[1, 1])

                jpos = [j * 2, j * 2 + 1]
                c[jpos, jpos] = xjacm

                # Create Bmat_s_d matrices
                Bmat_s_d = [self.create_Bmat_s(dxN[ii], dyN[ii], N[ii]) for ii in range(6)]
                Bmat_s = [np.hstack(Bmat_s_d[ii]) for ii in range(6)]
                Bs_mat = np.hstack(Bmat_s)

                # Append to B_bar
                B_bar = np.vstack([B_bar, Bs_mat])

            self.B_bar_all.append(B_bar)

            # Calculate bmat_ss
            bmat_ss = np.dot(np.dot(np.dot(np.dot(xjaci_eval, A), np.linalg.inv(self.P_mat)), self.T_mat), c) @ B_bar

            # Extract submatrices
            bmat_s1 = np.array([[0, 0, bmat_ss[0, 0]], [0, 0, bmat_ss[1, 0]]])
            bmat_s2 = np.array([[0, 0, bmat_ss[0, 3]], [0, 0, bmat_ss[1, 3]]])
            bmat_s3 = np.array([[0, 0, bmat_ss[0, 6]], [0, 0, bmat_ss[1, 6]]])
            bmat_s4 = np.array([[0, 0, bmat_ss[0, 9]], [0, 0, bmat_ss[1, 9]]])
            bmat_s5 = np.array([[0, 0, bmat_ss[0, 12]], [0, 0, bmat_ss[1, 12]]])
            bmat_s6 = np.array([[0, 0, bmat_ss[0, 15]], [0, 0, bmat_ss[1, 15]]])

            # Combine with transformation matrix
            bmat_s1 = np.hstack([np.dot(bmat_s1, self.T), bmat_ss[:, 1:3]])
            bmat_s2 = np.hstack([np.dot(bmat_s2, self.T), bmat_ss[:, 4:6]])
            bmat_s3 = np.hstack([np.dot(bmat_s3, self.T), bmat_ss[:, 7:9]])
            bmat_s4 = np.hstack([np.dot(bmat_s4, self.T), bmat_ss[:, 10:12]])
            bmat_s5 = np.hstack([np.dot(bmat_s5, self.T), bmat_ss[:, 13:15]])
            bmat_s6 = np.hstack([np.dot(bmat_s6, self.T), bmat_ss[:, 16:18]])

            Bs_eval = np.hstack([bmat_s1, bmat_s2, bmat_s3, bmat_s4, bmat_s5, bmat_s6])

            # Calculate stiffness matrices
            Ks = np.dot(np.dot(Bs_eval.T, self.Ds), Bs_eval) * self.area * wg
            Kb = np.dot(np.dot(Bb_eval.T, self.Db), Bb_eval) * self.area * wg
            Km = np.dot(np.dot(Bm_eval.T, self.Dm), Bm_eval) * self.area * wg

            # Calculate mass matrix
            N = N_mat(L2, L3)
            self.M += np.dot(np.dot(N.T, self.rho * np.diag([self.h, self.h, self.h, self.h ** 3 / 12, -self.h ** 3 / 12])), N) * self.area * wg
            self.Kg += Ks + Kb + Km

            self.xjacm_all.append(xjacm_eval)
            self.xjaci_all.append(xjaci_eval)
            self.Bb_all.append(Bb_eval)
            self.Bm_all.append(Bm_eval)
            self.Bs_all.append(Bs_eval)
            self.Ks_all.append(Ks)
            self.Kb_all.append(Kb)
            self.Km_all.append(Km)

        self.K = self.Kg
        self.C = np.zeros_like(self.Kg)

    def extract_pars(self):
        self.E = self.pars.get("E", 210e9)
        self.nu = self.pars.get("nu", 0.3)
        self.rho = self.pars.get("rho", 7850)
        self.h = self.pars.get("h", 5e-3)
        self.nodal_labels = self.pars.get("nodal_labels", [1, 2, 3, 4, 5, 6])
        self.nodal_coords = self.find_coords(self.my_nodes, self.nodal_labels)
        self.type = self.pars.get("type", "ps")
        self.dofs_q = self.pars.get("dofs_q", np.zeros((0, 2), dtype=np.int32))
        self.gauss_order = self.pars.get("gauss_order", 2)

    def create_Bmat_s(self, dx, dy, N):
        return np.array([[dx, -N, 0], [dy, 0, -N]])

    def rotation_matrix(self, cxyz):
        v12 = np.zeros(3)
        v13 = v12.copy()
        vxe = v12.copy()
        vye = v12.copy()
        vze = v12.copy()

        v12[0] = cxyz[1, 0] - cxyz[0, 0]
        v12[1] = cxyz[1, 1] - cxyz[0, 1]
        v12[2] = cxyz[1, 2] - cxyz[0, 2]

        v13[0] = cxyz[2, 0] - cxyz[0, 0]
        v13[1] = cxyz[2, 1] - cxyz[0, 1]
        v13[2] = cxyz[2, 2] - cxyz[0, 2]

        vze[0] = v12[1] * v13[2] - v12[2] * v13[1]
        vze[1] = v12[2] * v13[0] - v12[0] * v13[2]
        vze[2] = v12[0] * v13[1] - v12[1] * v13[0]

        dz = np.sqrt(vze[0]**2 + vze[1]**2 + vze[2]**2)

        vze /= dz

        vxe[0] =  1 / np.sqrt(1 + (vze[0] / vze[2]) ** 2)
        vxe[2] = -1 / np.sqrt(1 + (vze[2] / vze[0]) ** 2)

        dd = vxe[0] * vze[0] + vxe[2] * vze[2]
        if abs(dd) > 1e-8:
            vxe[2] = -vxe[2]

        if vze[2] == 0 and vze[0] == 0:
            vxe[0] = 1
            vxe[1] = 0
            vxe[2] = 0

        vye[0] = vze[1] * vxe[2] - vxe[1] * vze[2]
        vye[1] = vze[2] * vxe[0] - vxe[2] * vze[0]
        vye[2] = vze[0] * vxe[1] - vxe[0] * vze[1]

        dy = np.sqrt(vye[0]**2 + vye[1]**2 + vye[2]**2)
        vye /= dy

        if vye[1] < 0:
            vye = -vye
            vxe = -vxe

        Te = np.array([vxe, vye, vze])
        return Te

    def gl_quadrature_tri(self, order):
        if order == 1:
            x = np.array([[1, 1]]) * 1/3
            w = np.array([1.0])

        elif order == 2:
            x = np.array([[1/6, 1/6], [2/3, 1/6], [1/6, 2/3]])
            w = np.array([1, 1, 1]) * 1/3

        elif order == 3:
            gamma_1 = -27/48
            gamma_2 =  25/48
            x = np.array([[1/3, 1/3], [0.6, 0.2], [0.2, 0.6], [0.2, 0.2]])
            w = np.array([gamma_1, gamma_2, gamma_2, gamma_2])

        elif order == 4:
            alpha_1 = 0.8168475730
            alpha_2 = 0.1081030182
            beta_1  = 0.0915762135
            beta_2  = 0.4459484909
            gamma_3 = 0.2199034874 / 2
            gamma_4 = 0.4467631794 / 2
            x = np.array([[beta_1, beta_1], 
                          [alpha_1, beta_1], 
                          [beta_1, alpha_1], 
                          [alpha_2, beta_2], 
                          [beta_2, alpha_2], 
                          [beta_2, beta_2]])

            w = np.array([gamma_3, gamma_3, gamma_3, gamma_4, gamma_4, gamma_4])
            
        else:
            raise ValueError("Unsupported order")
        return x, w

# Additional functions and classes would need to be translated similarly.