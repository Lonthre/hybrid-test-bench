import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from scipy.linalg import block_diag
from yafem.nodes import nodes
from yafem.elem.core_elem import core_elem

#%% element_beam2d class
class beam2d(core_elem):

    # all element parameters are hidden
    _A : float # cross-section area
    _I : float # cross-section inertia
    _L : float # beam2d length
    _E : float # elastic modulus
    _Rho : float # density

    # class constructor
    def __init__(self, my_nodes, pars):

        # superclass constructor
        super().__init__(my_nodes,pars)

        # link the nodes to the element
        self.my_nodes = my_nodes

        # extract parameters and assign default values
        self.extract_pars(pars)

        # element dofs
        self.dofs = np.array([[self.nodal_labels[0],0],   #dof 0 = axial load
                              [self.nodal_labels[0],1],   #dof 1 = bending 
                              [self.nodal_labels[0],2],   #dof 2 = moment 
                              [self.nodal_labels[1],0],
                              [self.nodal_labels[1],1],
                              [self.nodal_labels[1],2]],dtype=np.int32)
        
        # no temperature dofs
        self.dofs_q = np.zeros((0,2))
        
        # rotation matrix in the xy plane
        s = (self.nodal_coords[1,:2] - self.nodal_coords[0,:2])/self._L
        t = np.array([-s[1],s[0]])
        R = np.array([s,t])

        # global to local transformation matrix in the xy plane
        self.G = sp.linalg.block_diag(R,[[1]],R,[[1]])

        # local stiffness matrix
        self.Kl = np.array([[self._E*self._A/self._L,0,0,-self._E*self._A/self._L,0,0],
                            [0,12*self._E*self._I/self._L**3,6*self._E*self._I/self._L**2,0, -12*self._E*self._I/self._L**3, 6*self._E*self._I/self._L**2],
                            [0,6*self._E*self._I/self._L**2,4*self._E*self._I/self._L,0,-6*self._E*self._I/self._L**2,2*self._E*self._I/self._L],
                            [-self._E*self._A/self._L,0,0,self._E*self._A/self._L,0,0],
                            [0,-12*self._E*self._I/self._L**3,-6*self._E*self._I/self._L**2, 0,12*self._E*self._I/self._L**3,-6*self._E*self._I/self._L**2],
                            [0,6*self._E*self._I/self._L**2,2*self._E*self._I/self._L,0,-6*self._E*self._I/self._L**2,4*self._E*self._I/self._L]],dtype=np.float64)

        # local mass matrix (TO BE ADDED LATER)
        Mn = self._A * self._L * self._Rho / 2
        In = self._A * self._L * self._Rho / 2 * self._L**2 / 3 # TO BE CHECKED !!

        # mass matrix in local coordinates
        self.Ml = np.zeros((6,6),dtype=np.float64)       
        self.Ml = np.diag(np.array([Mn,Mn,In,Mn,Mn,In]))

        # global stiffness matrix in the xy plane
        self.K = self.G.transpose() @ self.Kl @ self.G

        # global mass matrix in the xy plane
        self.M = self.G.transpose() @ self.Ml @ self.G

        # damping matrix in global coordinates
        self.C = np.zeros(self.K.shape).astype(np.float64)

    #%% extract parameters and assign default values
    def extract_pars(self,pars):

        self._A = float(pars.get('A', 1.0)) # cross-section area
        self._I = float(pars.get('I', 1.0)) # cross-section inertia
        self._E = float(pars.get('E', 1.0)) # elastic modulus
        self._Rho = float(pars.get('Rho', 1.0)) # density

        # node labels
        self.nodal_labels = pars.get('nodal_labels', np.array([0, 1], dtype=np.int32)).astype(np.int32)

        # extract nodal coordinates
        self.nodal_coords = self.my_nodes.find_coords(self.nodal_labels)

        # beam2d length
        self._L = np.linalg.norm(self.nodal_coords[1,:] - self.nodal_coords[0,:])

    #%% plot the element
    def plot(self):#,ax,ue,uscale):

        # plot the beam in 2d
        fig, ax = plt.subplots()
        ax.plot(self.nodal_coords[:, 0], self.nodal_coords[:, 1])
        plt.show()

        '''
        # Add the polygon patch to the axes
        #ax.add_patch(patches.Polygon(self.node_coord[:,0:2], color='blue', alpha=0.5))
        ax.plot(self.nodal_coord[:,0],self.nodal_coord[:,1], color='blue')

        # Update position
        pos = self.nodal_coord.copy() # be carefull !!!

        pos[0,0] = pos[0,0] + ue[0] * uscale
        pos[0,1] = pos[0,1] + ue[1] * uscale
        pos[1,0] = pos[1,0] + ue[3] * uscale
        pos[1,1] = pos[1,1] + ue[4] * uscale

        #ax.add_patch(patches.Polygon(pos[:,0:2], color='red', alpha=0.5))
        ax.plot(pos[:,0],pos[:,1], color='red')        
        '''
