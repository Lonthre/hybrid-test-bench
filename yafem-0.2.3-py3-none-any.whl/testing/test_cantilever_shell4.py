#%% Packages

import unittest        # The test framework
import numpy as np
from yafem.nodes import *
from yafem.model import *
from yafem.simulation import *
from yafem.elem import shell4

r = 200 # [mm]
L = 2000 # [mm]
P = -1e3 # [N]

#%% Nodes

import numpy as np

ElemSize = [8, 9]  # Element size [Radial, Longitudinal]
theta = 2 * np.pi / ElemSize[0]

# Nodal coordinates
nCoord = []
n = 0
for j in range(ElemSize[1] + 1):
    for i in range(1, ElemSize[0] + 1):
        n += 1
        x = j * L / ElemSize[1]
        y = r * np.cos(i * theta)
        z = r * np.sin(i * theta)
        nCoord.append([x, y, z])

nCoord = np.array(nCoord)
node_label = np.array([np.arange(len(nCoord)) + 1])


nodal_pars = {}
nodal_pars['nodal_data'] = np.empty((0, 4))
nodal_pars['nodal_data'] = np.hstack((node_label.T,nCoord))

myNodes = nodes(nodal_pars)

#%% Elements

# Element topology
eTop = []
n = 0  # reset counter
for j in range(1, ElemSize[1] + 1):  # loop over Altitude direction
    for i in range(1, ElemSize[0]):  # loop over Azimuth direction
        n += 1  # increase counter
        eTop.append([
            i + ElemSize[0] * (j - 1),
            i + ElemSize[0] * (j - 1) + 1,
            i + ElemSize[0] * j + 1,
            i + ElemSize[0] * j
        ])

eTop = np.array(eTop)

# Extend eTop in Python
additional_eTop = np.column_stack((
    np.arange(ElemSize[0], ElemSize[0] * ElemSize[1] + 1, ElemSize[0]),
    np.arange(1, ElemSize[0] * ElemSize[1] + 1, ElemSize[0]),
    np.arange(ElemSize[0] + 1, ElemSize[0] * ElemSize[1] + 2, ElemSize[0]),
    np.arange(ElemSize[0] * 2, ElemSize[0] * ElemSize[1] + ElemSize[0] + 1, ElemSize[0])))

# Concatenate the new rows to eTop
eTop = np.vstack((eTop, additional_eTop))

element_pars = {}
myElements = []

# Element parameters
shell_pars = [{ 'type': 'ps',
                'nodal_labels': eTop[i],
                'E': 210000,  # [MPa]
                'G': 81000,   # [MPa]
                'h': 50,      # [mm]
                'rho': 7850 * (1e-3 / 1e9),  # [ton/mm3]
              }  for i in range(len(eTop))]  

# Populate element_pars and create the corresponding elements
for i, params in enumerate(shell_pars):
        myElements.append(shell4(myNodes, params))
        


#%% Model

model_pars = {}
model_pars['dofs_c'] = []

for i in range(ElemSize[0]):
    model_pars['dofs_c'].append(np.array([[i+1,1],[i+1,2],[i+1,3],[i+1,4],[i+1,5],[i+1,6]]))

model_pars['dofs_c'] = np.vstack(model_pars['dofs_c'])
myModel = model(myNodes,myElements,model_pars)


#%%

# dofs applies with load
f_dofs = myModel.dofs[-ElemSize[0]*6:,:][2::6]

# Prealocate load vector
model_pars['dofs_f'] = np.zeros([np.shape(myModel.dofs)[0],1])

# Add load to the desired node
model_pars['dofs_f'][myModel.find_dofs(f_dofs)] = -1e3 / ElemSize[0]

# Solve the inverse system to determine kinematic quantities
d = np.linalg.solve(myModel.K.todense(),model_pars['dofs_f'])

ux = d[0::6]
uy = d[1::6]
uz = d[2::6]
rx = d[3::6]
ry = d[4::6]
rz = d[5::6]

uz_mean = np.mean(np.abs(uz[-ElemSize[0]:]))

# Analytically computed deflection result
E = 210000
h = 50

D = 2 * r + h
d = 2 * r - h
P = 1000

I = ((D**4-d**4) * np.pi)/64

du = (1/3) * (P*L**3)/(E*I)

#%% tests static analysis
class test_static_analysis(unittest.TestCase):

## Test nodal_deflection

    def test_defection_0(self,uz_mean=uz_mean,du=du): 

        delta = 0.0015

        # error message in case if test case got failed
        message = "first and second are not almost equal."

        # assert function() to check if values are almost equal
        self.assertAlmostEqual(uz_mean, du, None, message, delta) 

#%% 

if __name__ == '__main__':
    unittest.main()

