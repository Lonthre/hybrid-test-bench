import nox
import os
from pathlib import Path

# Reuse existing virtual environments
nox.options.reuse_existing_virtualenvs = True
requirements = False

@nox.session(python=["3.9", "3.10", "3.11", "3.12", "3.13"])
def unittest(session):
    """Run tests using unittest on specified Python versions."""

    parent_dir = Path(__file__).parent.parent

    if requirements == True:
        # Install dependencies from requirements.txt
        session.install("-r", os.path.join(parent_dir,"requirements.txt"))
    else:
        session.install('numpy',
                        'scipy',
                        'jax',
                        'jaxlib',
                        'matplotlib')

    # Add the parent directory (python/) to the PYTHONPATH
    session.env["PYTHONPATH"] = str(parent_dir)

    # Run specific unittest directly
    # session.run("python", "-m", "unittest", "test_yafem_basic.py")

    # Use unittest discovery to find and run all tests matching the pattern
    session.run("python", "-m", "unittest", "discover", "-s", ".", "-p", "test_*.py")


