#%% Packages

import unittest        # The test framework
import numpy as np
from yafem import nodes
from yafem.elem import snapthrough
from yafem import model
from yafem import simulation
import matplotlib.pyplot as plt

#%% test nodes basics
class test_snapthrough_basics(unittest.TestCase):

    # Define constants
    a = 1
    L = 1
    A = 1
    E = 1

    # Displacement range
    u = np.linspace(a * 0.5, -2.5 * a, 100)

    # Call from the class
    r = snapthrough.compute_r(A, E, a, L, u)
    K = snapthrough.compute_K(A, E, a, L, u)

## Test model

    def test_snapthrough_r_result(self,r=r):   

        r_res = np.hstack((r[0],r[10],r[20],r[30],r[40],r[-1]))

        self.assertEqual(r_res.all(), np.array([ 1.875, 0.51797242, -0.17956772, -0.38457926, -0.26402106, -1.875]).all())

    def test_snapthrough_K_result(self,K=K):   

        K_res = np.hstack((K[0],K[10],K[20],K[30],K[40],K[-1]))

        self.assertEqual(K_res.all(), np.array([ 5.75,  3.29820937,  1.39738292,  0.04752066, -0.75137741, 5.75]).all())


#%% 

if __name__ == '__main__':
    unittest.main()

