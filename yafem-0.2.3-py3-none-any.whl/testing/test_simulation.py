#%% Packages

import unittest        # The test framework
import numpy as np
from yafem import nodes
from yafem.elem import MCK
from yafem import model
from yafem import simulation
import matplotlib.pyplot as plt

#%% test nodes basics
class test_simulation_basics(unittest.TestCase):

    # nodal parametes
    nodes_pars = {}
    nodes_pars['nodal_data'] = np.array([[1,1,0,0],
                                        [2,0,1,0],
                                        [3,0,0,1]])

    # node object
    my_nodes = nodes(nodes_pars)

    # element parameters
    element_MCK_pars1 = {}
    element_MCK_pars1['K'] = np.array([[1.1]])
    element_MCK_pars1['M'] = np.array([[2.2]])
    element_MCK_pars1['dofs'] = np.array([[1,1]])

    # element object
    my_element_MCK1 = MCK(my_nodes,element_MCK_pars1)

    # element parameters
    element_MCK_pars2 = {}
    element_MCK_pars2['K'] = np.array([[ 2.1,-1.0, 0.0],
                                    [-1.0, 2.0,-1.0],
                                    [ 0.0,-1.0, 1.0]])

    element_MCK_pars2['M'] = np.array([[2.0,0.0,0.0],
                                    [0.0,2.0,0.0],
                                    [0.0,0.0,1.1]])

    element_MCK_pars2['dofs'] = np.array([[1,1],
                                        [2,1],
                                        [3,1]])
                                        
    #element_MCK_pars2['dofs_q'] = np.array([[1,6]])

    # element object
    my_element_MCK2 = MCK(my_nodes,element_MCK_pars2)

    # group of elements into a list
    myElements = [my_element_MCK1,my_element_MCK2]

    t = np.arange(0,10,0.1)

    model_pars = {}
    model_pars['dofs_f'] = np.array([[3,1]])
    model_pars['dofs_u'] = np.array([[2,1]])
    model_pars['dofs_c'] = np.array([[1,1]])
    model_pars['damping_model'] = 'proportional'
    model_pars['alpha'] = 2.0
    model_pars['beta'] = 0.1
    model_pars['dt'] = 0.1
    model_pars['step'] = len(t)
    model_pars['g_f'] = np.cos(np.pi*t)
    model_pars['g_u'] = 0.1*t

    my_model = model(my_nodes,myElements,model_pars)

    simulation_pars = {'recorder_tags':['my_elements[0].u[0]','my_elements[1].u[0]','my_elements[1].v[0]']}
    mySimulation = simulation(my_model,simulation_pars)

    [su,sv,sa] = mySimulation.static_analysis(output=False)
    [u,v,a,r]  = mySimulation.dynamic_analysis(output=False)

## Test model

    def test_stat_simulation_u_result(self,su=su):   

        su_res = np.vstack((np.hstack([su[0,:][10],su[0,:][40],su[0,:][-1]]),
                            np.hstack([su[1,:][10],su[1,:][40],su[1,:][-1]])))

        self.assertEqual(su_res.all(), np.array([[ 0.1, 0.4, 0.99],[-0.9, 1.4, 1.94105652]]).all())

    def test_stat_simulation_r_result(self,sa=sa):   

        r_res = np.vstack((np.hstack([sa[0,:][10],sa[0,:][40],sa[0,:][-1]]),
                           np.hstack([sa[1,:][10],sa[1,:][40],sa[1,:][-1]])))

        self.assertEqual(r_res.all(), np.array([[ 1.1, -0.6, 0.03894348],[-1.,  1., 0.95105652]]).all())

    def test_dyn_simulation_u_result(self,u=u):   

        u_res = np.vstack((np.hstack([u[0,:][10],u[0,:][40],u[0,:][-1]]),
                           np.hstack([u[1,:][10],u[1,:][40],u[1,:][-1]])))

        self.assertEqual(u_res.all(), np.array([[ 0.00515615, -0.00624882, -0.00175771],[ 0.04446401, -0.07596568, -0.08070715]]).all())

    def test_dyn_simulation_v_result(self,v=v):   

        v_res = np.vstack((np.hstack([v[0,:][10],v[0,:][40],v[0,:][-1]]),
                           np.hstack([v[1,:][10],v[1,:][40],v[1,:][-1]])))

        self.assertEqual(v_res.all(), np.array([[ 0.00943084, -0.01227414, -0.01091693],[-0.17212849,  0.15376003,  0.08025016]]).all())

    def test_dyn_simulation_a_result(self,a=a):   

        a_res = np.vstack((np.hstack([a[0,:][10],a[0,:][40],a[0,:][-1]]),
                           np.hstack([a[1,:][10],a[1,:][40],a[1,:][-1]])))

        self.assertEqual(a_res.all(), np.array([[-0.01133532,  0.00172966, -0.0116578 ],[-0.58406295,  0.6498558 ,  0.76758081]]).all())

#%% 

if __name__ == '__main__':
    unittest.main()

