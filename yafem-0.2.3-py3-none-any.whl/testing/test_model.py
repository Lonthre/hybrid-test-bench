#%% Packages

import unittest        # The test framework
import numpy as np
from yafem import nodes as nodes
from yafem.elem import MCK as MCK
from yafem import model as model

#%% test nodes basics
class test_model_basics(unittest.TestCase):

    # nodal parametes
    nodes_pars = {}
    nodes_pars['nodal_data'] = np.array([[0,0.0,0.0,0.0],[1,1.0,0.0,0.0],[2,0.0,1.0,0.0],[3,0.0,0.0,1.0]])

    # node object
    my_nodes = nodes(nodes_pars)

    # element parameters
    element_MCK_pars1 = {}
    element_MCK_pars1['K'] = np.array([[1.1]])
    element_MCK_pars1['M'] = np.array([[2.2]])
    element_MCK_pars1['dofs'] = np.array([[0,0]])
    #element_MCK_pars1['dofs_q'] = np.array([[0,6]])

    # element object
    my_element_MCK1 = MCK(my_nodes,element_MCK_pars1)

    # element parameters
    element_MCK_pars2 = {}
    element_MCK_pars2['K'] = np.array([[2.1,-1.0,0.0],[-1.0,2.0,-1.0],[0.0,-1.0,1.0]])
    element_MCK_pars2['M'] = np.array([[2.0,0.0,0.0],[0.0,2.0,0.0],[0.0,0.0,1.1]])
    element_MCK_pars2['dofs'] = np.array([[0,0],[0,1],[0,2]])

    # element object
    my_element_MCK2 = MCK(my_nodes,element_MCK_pars2)

    # group of elements into a list
    my_elements = [my_element_MCK1,my_element_MCK2]

    model_pars = {}
    model_pars['dofs_f'] = np.array([[0,0]])
    model_pars['dofs_u'] = np.array([[0,1]])
    model_pars['damping_model'] = 'proportional'
    model_pars['alpha'] = 2.0
    model_pars['beta'] = 0.1

    my_model = model(my_nodes,my_elements,model_pars)

## Test model

    def test_dofs_result(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs.all(), np.array([[0,0],[0,1],[0,2]]).all())

    def test_dofs_shape(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs.shape, (3, 2))

    def test_dofs_q_result(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs_q.all(), np.array([]).all())

    def test_dofs_q_shape(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs_q.shape, (0, 2))

    def test_dofs_f_result(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs_f.all(), np.array([[0,0]]).all())

    def test_dofs_f_shape(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs_f.shape, (1, 2))

    def test_dofs_u_result(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs_u.all(), np.array([[0,1]]).all())

    def test_dofs_u_shape(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.dofs_u.shape, (1, 2))

## Test find functions

    def test_find_dofs(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.find_dofs([[0,0],[0,1]]).all(), np.array([[0,1]]).all())

    def test_find_nodes(self,my_model=my_model):   
            # test if the shape is a 1D array
            self.assertEqual(my_model.find_nodes([0]).all(), np.array([[0,1,2]]).all())

    def test_find_dirs(self,my_model=my_model):   
            # test if the shape is a 1D array
            self.assertEqual(my_model.find_dirs([2]).all(), np.array([2]).all())

# Test Bu and Bf collocation maticies

    def test_Bu_result(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.Bu.todense().all(), np.array([[0],[1],[0]]).all())

    def test_Bu_shape(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.Bu.todense().shape, (3, 1))

    def test_Bf_result(self,my_model=my_model):   
            # test if the shape is a 1D array
            self.assertEqual(my_model.Bf.todense().all(), np.array([[1],[0],[0]]).all())

    def test_Bf_shape(self,my_model=my_model):   
        # test if the shape is a 1D array
        self.assertEqual(my_model.Bf.todense().shape, (3, 1))

#%% 

if __name__ == '__main__':
    unittest.main()

