#%% Packages

import unittest        # The test framework
import numpy as np
from yafem import nodes as nodes

#%% test nodes basics
class test_nodes_basics(unittest.TestCase):

    # creation of a nodes object
    pars = {}
    pars['nodal_data'] = np.array([[1,0.0,0.0,0.0],
                                   [2,1.0,0.0,0.0],
                                   [3,0.0,1.0,0.0],
                                   [4,0.0,0.0,1.0],
                                   [5,0.5,1.0,0.0]])
                                
    my_nodes = nodes(pars)

## Test nodal_labels

    def test_nodal_labels_shape(self,my_nodes=my_nodes):   
        # test if the shape is a 1D array
        self.assertEqual(len(np.shape(my_nodes.nodal_labels)), 1)

    def test_nodal_labels_type(self,my_nodes=my_nodes):   
        # test data type nodal_coords accept
        self.assertEqual(my_nodes.nodal_labels.dtype, 'int32')

## Test nodal_coords

    def test_nodal_coords_shape(self,my_nodes=my_nodes):
        # test if the shape is a 2D array
        self.assertEqual(len(np.shape(my_nodes.nodal_coords)), 2)

    def test_nodal_coords_dim(self,my_nodes=my_nodes):   
        # test if there is a x,y and z dimension in nodal_coords
        self.assertEqual(np.shape(my_nodes.nodal_coords)[1], 3)

    def test_nodal_coords_type(self,my_nodes=my_nodes):   
        # test data type nodal_coords accept
        self.assertEqual(my_nodes.nodal_coords.dtype, 'float64')

## Test find_coords

    def test_find_coords(self,my_nodes=my_nodes):

        sel = np.array([3,2])
        data1 = my_nodes.nodal_coords[my_nodes.nodal_labels == sel[0]]
        data2 = my_nodes.nodal_coords[my_nodes.nodal_labels == sel[1]]

        check_find_coords = np.vstack((data1,data2))
        nodal_coords_sel = my_nodes.find_coords(sel)

        # test if the found coords are equal to the more manual detection
        self.assertEqual(nodal_coords_sel.all(), check_find_coords.all())

## Test model_center

    def test_model_center(self,my_nodes=my_nodes):   
        check_model_center = []
        for i in range(3):
            check_model_center.append(sum(my_nodes.nodal_coords[:,i])/len(my_nodes.nodal_coords))
        
        # test if manual setup of check_model_center is equal to the optimized model_center
        self.assertEqual(list(my_nodes.model_center), list(check_model_center))

## Test model_size

    def test_model_size(self,my_nodes=my_nodes):   
        check_model_size = 0
        for i in range(len(my_nodes.nodal_coords)):
            for j in range(len(my_nodes.nodal_coords)):
                check_model_size = max(check_model_size, ((my_nodes.nodal_coords[i,0]-my_nodes.nodal_coords[j,0])**2 
                                                         +(my_nodes.nodal_coords[i,1]-my_nodes.nodal_coords[j,1])**2
                                                         +(my_nodes.nodal_coords[i,2]-my_nodes.nodal_coords[j,2])**2)**0.5)

        # test if manual setup of check_model_size is equal to the optimized model_size
        self.assertEqual(my_nodes.model_size, check_model_size)


# Test nodal plot

    def test_plot(self,my_nodes=my_nodes):   
        self.assertEqual(str(my_nodes.plot()), str('Axes3D(0.125,0.11;0.775x0.77)'))

    def test_plot_with_labels_as_number(self,my_nodes=my_nodes):   
        self.assertEqual(str(my_nodes.plot(labels = 16)), str('Axes3D(0.125,0.11;0.775x0.77)'))



#%% test boundaries of nodal data extraction

class test_extract_nodal_data(unittest.TestCase):

# Test when two coordinates are equal, but the labels are not equal

    def test_equal_coords_nonequal_labels(self):

        # creation of a nodes object
        pars = {}
        pars['nodal_data'] = np.array([[1,1.0,0.0,0.0],
                                       [2,1.0,0.0,0.0],
                                       [3,0.0,1.0,0.0],
                                       [4,0.0,0.0,1.0],
                                       [5,0.5,1.0,0.0]])

        with self.assertRaises(Exception) as context:
            nodes(pars)

        # Check the exception message
        self.assertIn("Repeated nodal coordinates at label:", str(context.exception))
    
# Test when two labels are equal, but the coordinates are not equal

    def test_equal_labels_nonequal_coords(self):

        # creation of a nodes object
        pars = {}
        pars['nodal_data'] = np.array([[1,0.0,0.0,0.0],
                                       [1,1.0,0.0,0.0],
                                       [3,0.0,1.0,0.0],
                                       [4,0.0,0.0,1.0],
                                       [5,0.5,1.0,0.0]])

        with self.assertRaises(Exception) as context:
            nodes(pars)

        # Check the exception message
        self.assertIn("Repeated nodal label(s):", str(context.exception))


# Test when certain labels and coordinates are equal, but not all of them

    def test_nonequal_labels_nonequal_coords(self):

        # creation of a nodes object
        pars = {}
        pars['nodal_data'] = np.array([[1,0.0,0.0,0.0],
                                       [1,1.0,0.0,0.0],
                                       [3,1.0,0.0,0.0],
                                       [3,0.0,0.0,1.0],
                                       [5,0.5,1.0,0.0]])

        with self.assertRaises(Exception) as context:
            nodes(pars)

        # Check the exception message
        self.assertIn("Inconsistent repeated nodal label(s):", str(context.exception))

# Test when lower dimension is parsed to "nodes" instead of xyz 
    
    def test_parsed_only_xy_coords(self):

        # creation of a nodes object
        pars = {}
        pars['nodal_data'] = np.array([[1,0.0,0.0],
                                       [2,1.0,0.0]])

        myNodes = nodes(pars)

        # Check the exception message
        self.assertEqual(str((myNodes.nodal_coords).shape), str('(2, 3)'))

# Test when no "pars" have been given to "nodes"

    def test_no_pars_parsed(self):

        # creation of a nodes object
        pars = {}

        myNodes = nodes(pars)

        # Check the exception message
        self.assertEqual(str((myNodes.nodal_coords).shape), str('(1, 3)'))


#%% 

if __name__ == '__main__':
    unittest.main()

