#%% Packages

import unittest        # The test framework
import numpy as np
import scipy as sp
from yafem.nodes import *
from yafem.model import *
from yafem.simulation import *
from yafem.elem import beam3d

#%% Nodes

nodal_pars = {}

nodal_pars['nodal_data'] = np.empty((0, 4))
nodal_pars['nodal_data'] = np.array([[1,0,0,0],
                                     [2,1,0,0],
                                     [3,2,0,0],
                                     [4,3,0,0]])
                                    
nodal_pars['nodal_data'][:,1:] = nodal_pars['nodal_data'][:,1:] * 10**3
myNodes = nodes(nodal_pars)

#%% Elements

myElements = []
element_pars = {}

for i in range(np.shape(nodal_pars['nodal_data'])[0]-1):
    element_pars['D1'] = 100
    element_pars['D2'] = 100
    element_pars['E']  = 210000
    element_pars['H']  = 10
    element_pars['rho'] = 7850 * 10**-3/10**9
    element_pars['alpha'] = 0
    element_pars['theta'] = 0
    element_pars['nu'] = 0.3
    element_pars['G'] = element_pars["E"] / (2 * (1 + element_pars["nu"]))

    element_pars['nodal_labels'] = np.array([1,2]) + i
    element_pars['nodal_coords'] = myNodes.find_coords(element_pars['nodal_labels'])

    element = beam3d(myNodes, element_pars)  # Assuming the existence of this class
    myElements.append(element)


#%% Model

model_pars = {}

model_pars['dofs_c'] = np.array([[1,1],
                                 [1,2],
                                 [1,3],
                                 [1,4],
                                 [1,5],
                                 [1,6]])

model_pars['dofs_f'] = np.array([[4,2]])
model_pars['dofs_u'] = np.array([[1,1]])
model_pars['damping_model'] = 'proportional'
model_pars['alpha'] = 2.0
model_pars['beta'] = 0.1
model_pars['dt'] = 0.1

t = np.arange(0,10,model_pars['dt'])
model_pars['step'] = len(t)
model_pars['g_f'] = -1e3 * np.ones_like(t)
model_pars['g_u'] = 0.1*t

myModel  = model(myNodes,myElements,model_pars)

omega, phi = myModel.compute_modal(1)

# Prealocate load vector
model_pars['dofs_f'] = np.zeros([np.shape(myModel.dofs)[0],1])

# Add load to the desired node
model_pars['dofs_f'][myModel.find_dofs([[4,2]])] = -1e3
F = model_pars['dofs_f'][myModel.find_dofs([[4,2]])]

# Solve the inverse system to determine kinematic quantities
d = np.linalg.solve(myModel.K.todense(),model_pars['dofs_f'])

ux = d[0::6]
uy = d[1::6]
uz = d[2::6]
rx = d[3::6]
ry = d[4::6]
rz = d[5::6]

# Analytically computed deflection result
A = np.pi * (element_pars['D1']/2)**2 - np.pi * ((element_pars['D1']/2)-element_pars['H'])**2
m = element_pars['rho'] * A
I = (np.pi/4) * ((element_pars['D1']/2)**4 - ((element_pars['D1']/2)-element_pars['H'])**4)
L = myElements[0].L * 3
E = element_pars['E']

du = lambda x: (1/2) * ((F*3000**3)/(E*I))*((2/3)-(x/3000)+(1/3)*(x/3000)**3)

# Simulations
mySimulation = simulation(myModel)
[u_stat,l_stat,r_stat] = mySimulation.static_analysis(output=False)
[u_dyn,v_dyn,a_dyn,r_dyn] = mySimulation.dynamic_analysis(output=False)

#%% tests static analysis
class test_matrix_symmetry(unittest.TestCase):

## Test nodal_deflection

    def test_symmetry_K(self,myModel=myModel): 

        # test if the shape is a 1D array
        self.assertEqual(sp.linalg.issymmetric(myModel.K.todense()), True) 

    def test_symmetry_M(self,myModel=myModel): 

        # test if the shape is a 1D array
        self.assertEqual(sp.linalg.issymmetric(myModel.M.todense()), True) 

    def test_symmetry_C(self,myModel=myModel): 

        # test if the shape is a 1D array
        self.assertEqual(sp.linalg.issymmetric(myModel.C.todense()), True) 


#%% tests static analysis
class test_static_analysis(unittest.TestCase):

## Test nodal_deflection

    def test_defection_0(self,uy=uy,du=du(0)): 

        message = "first and second are not almost equal."

        # test if the shape is a 1D array
        self.assertAlmostEqual(uy[-1][0], du[0][0], 10, message) 

    def test_defection_1000(self,uy=uy,du=du(1000)): 

        message = "first and second are not almost equal."

        # test if the shape is a 1D array
        self.assertAlmostEqual(uy[-2][0], du[0][0], 10, message) 

    def test_defection_2000(self,uy=uy,du=du(2000)): 

        message = "first and second are not almost equal."

        # test if the shape is a 1D array
        self.assertAlmostEqual(uy[-3][0], du[0][0], 10, message)


#%% tests static analysis
class test_simulations(unittest.TestCase):

## Test nodal_deflection

    def test_static_defection_0(self,u_stat=u_stat,du=du(0)): 

        # test if the shape is a 1D array
        self.assertAlmostEqual(u_stat[1::6,-1][-1], du[0][0], 3)

    def test_dynamic_defection_0(self,u_dyn=u_dyn,du=du(0)): 

        # test if the shape is a 1D array
        self.assertAlmostEqual(u_dyn[1::6,-1][-1], du[0][0], 3)


#%% tests static analysis
class test_modal_analysis(unittest.TestCase):

## Test nodal_deflection

    def test_eigenfrequency(self,myModel=myModel): 

        omega_chopra = (3.516 / L**2) * np.sqrt((E*I)/m)/(2*np.pi)

        # test if the shape is a 1D array
        self.assertAlmostEqual(myModel.omega[0], omega_chopra, 2) 

 
#%% 

if __name__ == '__main__':
    unittest.main()

