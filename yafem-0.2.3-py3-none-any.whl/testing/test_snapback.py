#%% Packages

import unittest        # The test framework
import numpy as np
from yafem import nodes
from yafem.elem import snapback
from yafem import model
from yafem import simulation
import matplotlib.pyplot as plt

#%% test nodes basics
class test_snapback_basics(unittest.TestCase):

    nodal_pars = {}
    nodal_pars['nodal_data'] = np.empty((0, 4))

    nodal_pars['nodal_data'] = np.array([[1,0,0,0],
                                         [2,1,0,0],])

    myNodes = nodes(nodal_pars)

    myElements = []
    element_pars = {}
    element_pars['nodal_labels'] = np.array([1,2])

    element = snapback(myNodes,element_pars)
    myElements.append(element)

    model_pars = {}

    model_pars['dofs_u'] = np.array([[1,1]])
    model_pars['g_u'] = np.arange(0,5+1e-3,1e-3)

    myModel  = model(myNodes,myElements,model_pars)

    mySimulation = simulation(myModel)

    [u,l,r] = mySimulation.arclen_analysis(output=False)

## Test model

    def test_arc_len_l_result(self,l=l):   

        l_res = np.hstack([l[0,:][10],
                           l[0,:][1000],
                           l[0,:][2000],
                           l[0,:][3000],
                           l[0,:][4000],
                           l[0,:][-1]])

        self.assertEqual(l_res.all(), np.array([ 0.00239309,  0.21714049,  0.01258954, -0.22781005, -0.01564188,0.23129202]).all())

#%% 

if __name__ == '__main__':
    unittest.main()

