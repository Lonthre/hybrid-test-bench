#%% Packages

import unittest        # The test framework
import numpy as np
from yafem import nodes as nodes
from yafem.elem import MCK as MCK

#%% test nodes basics
class test_MCK_1dof_basics(unittest.TestCase):

    # nodal parametes
    nodes_pars = {}
    nodes_pars['nodal_data'] = np.array([[0,0.0,0.0,0.0],
                                         [1,1.0,0.0,0.0],
                                         [2,0.0,1.0,0.0],
                                         [3,0.0,0.0,1.0]])

    # node object
    my_nodes = nodes(nodes_pars)

    # model dofs
    dofs = np.array([[0,0],
                     [0,1],
                     [0,2],
                     [1,0],
                     [1,1],
                     [1,2]])

    dofs_q = np.array([[0,6],
                       [1,6]])

    # element parameters
    element_MCK_pars1 = {}
    element_MCK_pars1['K'] = np.array([[1.0]])
    element_MCK_pars1['dofs'] = np.array([[0,1]])

    # element object
    my_element_MCK1 = MCK(my_nodes,element_MCK_pars1)

    my_element_MCK1.compute_Zu(dofs)
    my_element_MCK1.compute_Zq(dofs_q)

    u = np.ones((my_element_MCK1.dofs.shape[0]))
    v = np.ones((my_element_MCK1.dofs.shape[0]))
    q = np.ones((my_element_MCK1.dofs_q.shape[0]))
    t = 0.0
    i = 1

    my_element_MCK1.compute_r(u,v,q,t,i)

## Test nodal_labels
    def test_K_not_given(self):   
            # nodal parametes
        nodes_pars = {}
        nodes_pars['nodal_data'] = np.array([[0,0.0,0.0,0.0],
                                            [1,1.0,0.0,0.0],
                                            [2,0.0,1.0,0.0],
                                            [3,0.0,0.0,1.0]])

        # node object
        my_nodes = nodes(nodes_pars)

        # model dofs
        dofs = np.array([[0,0],
                        [0,1],
                        [0,2],
                        [1,0],
                        [1,1],
                        [1,2]])

        dofs_q = np.array([[0,6],
                        [1,6]])

        # element parameters
        element_MCK_pars1 = {}
        element_MCK_pars1['dofs'] = np.array([[0,1]])

        with self.assertRaises(Exception) as context:
            MCK(my_nodes,element_MCK_pars1)

        # Check the exception message
        self.assertIn("the stiffness parameter must be defined", str(context.exception))

    def test_K_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.K, 1)

    def test_K_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.K.shape, (1, 1))

    def test_C_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.C, 0)

    def test_C_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.C.shape, (1, 1))

    def test_M_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.M, 0)

    def test_M_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.M.shape, (1, 1))

    def test_dofs_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs.all(), np.array([[0,1]]).all())

    def test_dofs_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs.shape, (1, 2))

    def test_dofs_q_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs_q.all(), np.array([]).all())

    def test_dofs_q_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs_q.shape, (0, 2))

    def test_Zu_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zu.todense().all(), np.array([[0, 1, 0, 0, 0, 0]]).all())

    def test_Zu_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zu.todense().shape, (1, 6))
        
    def test_Zq_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zq.todense().all(), np.array([]).all())

    def test_Zq_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zq.todense().shape, (0, 2))

    def test_r_result(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.r, 1)

    def test_r_shape(self,my_element_MCK=my_element_MCK1):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.r.shape, (1,))

#%% test nodes basics
class test_MCK_2dof_basics(unittest.TestCase):

    # nodal parametes
    nodes_pars = {}
    nodes_pars['nodal_data'] = np.array([[0,0.0,0.0,0.0],
                                         [1,1.0,0.0,0.0],
                                         [2,0.0,1.0,0.0],
                                         [3,0.0,0.0,1.0]])

    # node object
    my_nodes = nodes(nodes_pars)

    # model dofs
    dofs = np.array([[0,0],
                     [0,1],
                     [0,2],
                     [1,0],
                     [1,1],
                     [1,2]])

    dofs_q = np.array([[0,6],
                       [1,6]])
 
    # element parameters
    element_MCK_pars2 = {}
    element_MCK_pars2['K'] = np.array([[2.0,-1.0],[-1.0,1.0]])
    element_MCK_pars2['dofs'] = np.array([[0,1],[1,0]])

    # element object
    my_element_MCK2 = MCK(my_nodes,element_MCK_pars2)

    my_element_MCK2.compute_Zu(dofs)
    my_element_MCK2.compute_Zq(dofs_q)

    u = np.ones((my_element_MCK2.dofs.shape[0]))
    v = np.ones((my_element_MCK2.dofs.shape[0]))
    q = np.ones((my_element_MCK2.dofs_q.shape[0]))
    t = 0.0
    i = 1

    my_element_MCK2.compute_r(u,v,q,t,i)

## Test nodal_labels
    def test_K_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.K.all(), np.array([[2,-1],[-1,1]]).all())

    def test_K_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.K.shape, (2, 2))

    def test_C_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.C.all(), np.array([[0,0],[0,0]]).all())

    def test_C_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.C.shape, (2, 2))

    def test_M_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.M.all(), np.array([[0,0],[0,0]]).all())

    def test_M_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.M.shape, (2, 2))

    def test_dofs_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs.all(), np.array([[0,1],[1,0]]).all())

    def test_dofs_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs.shape, (2, 2))

    def test_dofs_q_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs_q.all(), np.array([]).all())

    def test_dofs_q_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.dofs_q.shape, (0, 2))

    def test_Zu_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zu.todense().all(), np.array([[0, 1, 0, 0, 0, 0],[0, 0, 0, 1, 0, 0]]).all())

    def test_Zu_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zu.todense().shape, (2, 6))
        
    def test_Zq_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zq.todense().all(), np.array([]).all())

    def test_Zq_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.Zq.todense().shape, (0, 2))

    def test_r_result(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.r.all(), np.array([1,0]).all())

    def test_r_shape(self,my_element_MCK=my_element_MCK2):   
        # test if the shape is a 1D array
        self.assertEqual(my_element_MCK.r.shape, (2,))


#%% 

if __name__ == '__main__':
    unittest.main()

