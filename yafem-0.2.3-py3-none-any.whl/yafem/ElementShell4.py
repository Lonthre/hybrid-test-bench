import numpy as np
from scipy.sparse import csr_array
from scipy.linalg import block_diag
from yafem.nodes import nodes
from yafem.elements import element
from yafem.ElementPlate_func import *
from yafem.ElementSolid_func import *

class ElementShell4(element):

    xe = np.array([], dtype=np.float64)
    xep = np.array([], dtype=np.float64)
    xe_plot = np.array([], dtype=np.float64)
    dofs_q = np.array([], dtype=np.int64)
    Zs = csr_array((0, 0), dtype=np.float64)
    Zp = csr_array((0, 0), dtype=np.float64)
    Zd = csr_array((0, 0), dtype=np.float64)
    type = ""
    T      = np.array([], dtype=np.float64)
    Mp     = np.array([], dtype=np.float64)
    Mb     = np.array([], dtype=np.float64)
    Kb     = np.array([], dtype=np.float64)
    Ks     = np.array([], dtype=np.float64)
    Ks2    = np.array([], dtype=np.float64)
    Ks1    = np.array([], dtype=np.float64)
    Kp     = np.array([], dtype=np.float64)
    Kd     = np.array([], dtype=np.float64)
    Kso    = np.array([], dtype=np.float64)
    fc     = np.array([], dtype=np.float64)
    d      = np.array([], dtype=np.float64)
    Kg     = np.array([], dtype=np.float64)
    Mg     = np.array([], dtype=np.float64)
    fcg    = np.array([], dtype=np.float64)
    ftg    = np.array([], dtype=np.float64)
    Kgs    = np.array([], dtype=np.float64)
    Mgs    = np.array([], dtype=np.float64)
    ftgs   = np.array([], dtype=np.float64)
    fcgs   = np.array([], dtype=np.float64)
    eps_n  = np.array([], dtype=object)
    eps_s  = np.array([], dtype=object)
    sig_n  = np.array([], dtype=object)
    sig_s  = np.array([], dtype=object)
    Dbp    = np.array([], dtype=np.float64)
    Dsp    = np.array([], dtype=np.float64)
    Kgp    = np.array([], dtype=np.float64)
    Mgp    = np.array([], dtype=np.float64)
    ftgp   = np.array([], dtype=np.float64)
    fcgp   = np.array([], dtype=np.float64)
    fcp    = np.array([], dtype=np.float64)
    B      = np.array([], dtype=np.float64)
    defb   = np.array([], dtype=object)
    forb   = np.array([], dtype=object)
    defs   = np.array([], dtype=object)
    fors   = np.array([], dtype=object)
    Kgd    = np.array([], dtype=np.float64)
    Mgd    = np.array([], dtype=np.float64)
    ftgd   = np.array([], dtype=np.float64)
    fcgd   = np.array([], dtype=np.float64)
    fcl    = np.array([], dtype=np.float64)
    ftl    = np.array([], dtype=np.float64)
    Ke     = np.array([], dtype=np.float64)
    stress = np.array([], dtype=np.float64)
    s      = 0.0
    E      = 0.0
    nu     = 0.0
    rho    = 0.0
    h      = 0.0
    alpha  = 0.0
    delta  = 0.0
    epsilon = 0.0
    bx = 0.0
    by = 0.0
    bz = 0.0
    ds = np.array([], dtype=np.float64)
    dp = np.array([], dtype=np.float64)
    dd = np.array([], dtype=np.float64)
    D  = np.array([], dtype=np.float64)

    # class constructor
    def __init__(self, my_nodes, pars):

        # superclass constructor
        super().__init__(my_nodes,pars)
        
        # element classification following GMSH
        self.element_type = 'quad4' # TO BE CHECKED

        # link the nodes to the element
        self.my_nodes = my_nodes
        
        # extract parameters and assign default values
        self.extract_pars(pars)

        # element dofs
        self.dofs = self.element_dofs(6)
        
        # Calculate the mean of nodal coordinates
        r0 = np.mean(self.nodal_coords, axis=0)
        xp = (self.nodal_coords[1, :] + self.nodal_coords[2, :]) / 2 - r0
        xp = xp / np.linalg.norm(xp)
        yp = (self.nodal_coords[2, :] + self.nodal_coords[3, :]) / 2 - r0
        yp = yp - np.dot(yp, xp)
        yp = yp / np.linalg.norm(yp)
        zp = np.cross(xp, yp)

        self.xe = self.nodal_coords
        self.xe_plot = self.xe
        self.xep = np.zeros((4, 2))
        for i in range(self.xe.shape[0]):
            self.xep[i, :] = np.dot((self.xe[i, :] - r0), np.column_stack((xp, yp)))

        self.xe = self.xep

        # Local reference system
        self.T = np.array([xp, yp, zp])

        # Transformation matrix for the displacement vector of a single node
        # Assuming BlockDiagonal is a placeholder for an actual block diagonal matrix construction
        # For simplicity, using np.kron (Kronecker product) to simulate block diagonal behavior
        self.G = np.kron(np.eye(8), self.T)  # Adjust based on actual BlockDiagonal implementation

        inds = [1, 2]
        indp = [3, -5, 4]
        indd = [6]

        self.Zs = self.fun_mapping(inds)
        self.Zp = self.fun_mapping(indp)
        self.Zd = self.fun_mapping(indd)
                
        d = np.zeros((24, 1))

        self.ds = self.Zs.dot(self.G.dot(d))
        self.dp = self.Zp.dot(self.G.dot(d))
        self.dd = self.Zd.dot(self.G.dot(d))

        self.compute_solid_pars()
        self.compute_plate_pars()
        self.compute_drilling_pars()

        self.Kl = np.zeros((24, 24))
        self.Ml = np.zeros((24, 24))
        self.fcl = np.zeros((24, 1))
        self.ftl = np.zeros((24, 1))

        # Local stiffness matrix of the shell element
        self.Kl += self.Zs.T @ self.Kgs @ self.Zs
        self.Kl += self.Zp.T @ self.Kgp @ self.Zp
        self.Kl += self.Zd.T @ self.Kgd @ self.Zd

        # Local mass matrix of the shell element
        self.Ml += self.Zs.T @ self.Mgs @ self.Zs
        self.Ml += self.Zp.T @ self.Mgp @ self.Zp
        self.Ml += self.Zd.T @ self.Mgd @ self.Zd

        # Local consistent nodal load vector
        self.fcl += self.Zs.T @ self.fcgs
        self.fcl += self.Zp.T @ self.fcgp
        self.fcl += self.Zd.T @ self.fcgd

        # Thermo mechanical load vector
        self.ftl += self.Zs.T @ self.ftgs
        self.ftl += self.Zp.T @ self.ftgp
        self.ftl += self.Zd.T @ self.ftgd

        # Element matrices and vectors in global reference system (model)
        self.Kg = self.G.T @ self.Kl @ self.G
        self.Mg = self.G.T @ self.Ml @ self.G
        self.fcg = self.G.T @ self.fcl
        self.ftg = self.G.T @ self.ftl
        self.K = self.Kg
        self.M = self.Mg
        self.C = np.zeros(self.K.shape)

    def element_dofs(self, dofs_per_node):
        # self.dofs = np.zeros((len(self.nodal_labels)*dofs_per_node, 2))  # Initialize self.dofs as an empty array
        # k = 0
        # for i, label in enumerate(self.nodal_labels):
        #     for j in range(1, dofs_per_node + 1):
        #         self.dofs[k, :] = [label, j]
        #         k += 1
        # return self.dofs
  
        self.dofs = np.empty([dofs_per_node*4,2],dtype=int)

        self.dofs[0:dofs_per_node,0] = self.nodal_labels[0] # Label of first node
        self.dofs[dofs_per_node*1:dofs_per_node*2,0]  = self.nodal_labels[1] # Label of second node
        self.dofs[dofs_per_node*2:dofs_per_node*3,0]  = self.nodal_labels[2] # Label of third node
        self.dofs[dofs_per_node*3:dofs_per_node*4,0]  = self.nodal_labels[3] # Label of fourth node
        self.dofs[:,1] = np.tile(np.arange(0,dofs_per_node), 4) + 1 # Dofs of all nodes
    
        return self.dofs

    def gl_quadrature(self, n):
        """
        Gauss-Legendre quadrature rule in Python.
        
        :param n: Number of points
        :return: points (s) and weights (w)
        """
        s = {
            1: [0],
            2: [-0.577350, 0.577350],
            3: [-0.774597, 0, 0.774597],
            4: [-0.861136, -0.339981, 0.339981, 0.861136],
            5: [-0.906179, -0.538469, 0.000000, 0.538469, 0.906179]
        }

        w = {
            1: [2],
            2: [1, 1],
            3: [5/9, 8/9, 5/9],
            4: [0.347855, 0.652145, 0.652145, 0.347855],
            5: [0.236926, 0.478628, 0.568888, 0.478628, 0.236926]
        }

        return s[n], w[n]
    
    def polyarea(self, xe):
            """
        Calculate the area of a polygon given its vertices in the form of a 2D array.
        
        Parameters:
        xe (list of lists or numpy array): A 2D array where each row contains the x and y coordinates of a vertex.
        
        Returns:
        float: The area of the polygon.
        """
            A2 = 0
            n = len(xe)
            for i in range(n):
                j = (i + 1) % n  # Get the next index, wrap around to 0 if at the end
                P = [[xe[i][0], xe[i][1]], [xe[j][0], xe[j][1]]]
                A2 += P[0][0]*P[1][1] - P[1][0]*P[0][1]  # Determinant of P
            return abs(A2 / 2)

    def compute_solid_pars(self, ds=None):
        """
        Compute the solid parameters for the element.
        """
        if ds is None:
            ds = np.zeros((8, 1))

        # Assuming e_fun_solid is an object or module that contains the functions Dps, Dpe, and Dax
        type_to_D = {
            'ps': ElementSolid_Dps,
            'pe': ElementSolid_Dpe,
            'ax': ElementSolid_Dax
        }

        # Assuming 'e' is an object that has attributes 'type', 'E', and 'nu'
        # Attempt to get the function based on e.type, default to raising an error if not found
        if self.type in type_to_D:
            D = type_to_D[self.type]
            self.D = D(self.E, self.nu)  # Call the function with e.E and e.nu as arguments
        else:
            raise ValueError("Type is not specified correctly!")
 
        sf, wf = self.gl_quadrature(2)
        sr, wr = self.gl_quadrature(1)

        self.Kgs = np.zeros((8, 8))
        self.Mgs = np.zeros((8, 8))
        self.fcgs = np.zeros((8, 1))
        # Initialize 2D arrays to store strain and stress
        self.eps_n = np.empty((2, 2), dtype=object)
        self.sig_n = np.empty((2, 2), dtype=object)
        self.eps_s = np.empty((1, 1), dtype=object)
        self.sig_s = np.empty((1, 1), dtype=object)


        if self.type == "ax":
            # Gauss-Legendre integration (full)
            sf, wf = self.gl_quadrature(2)
            for i in range(len(sf)):
                for j in range(len(sf)):
                    # Jacobian of the iso-parametric mapping in the point ij
                    Jac = ElementSolid_Jac(sf[i], sf[j], self.xe).reshape((2, 2))

                    # Strain interpolation matrix
                    N = ElementSolid_N(sf[i], sf[j])

                    # Shape functions
                    phi = ElementSolid_phi(sf[i], sf[j])

                    # Density
                    rho_ij = np.dot(phi, self.xe[:, 1])

                    inv_Jac = np.linalg.inv(Jac)    
                    inv_Jac_blc = block_diag(inv_Jac, inv_Jac)

                    # Strain interpolation matrix
                    B = np.vstack([
                        np.dot(np.array([[1, 0, 0, 0], [0, 0, 0, 1]]), inv_Jac_blc.T) @ ElementSolid_B(sf[i], sf[j]),
                        np.dot(np.array([1, 0]), N) / rho_ij
                    ])

                    # Done once per gauss point
                    dJ = np.linalg.det(Jac) * wf[i] * wf[j] * rho_ij
                    
                    if dJ < 0:
                        raise('negative determinant of the jacobian')

                    # Gauss-Legendre sum for stiffness
                    self.Kgs += B.T @ self.D[0:3, 0:3] @ B * dJ * 2 * np.pi

                    # Gauss-Legendre sum for mass
                    self.Mgs += N.T @ N * self.rho * dJ * 2 * np.pi

                    # strain (e_rr,e_yy,e_tt)
                    self.eps_n[i, j] = B @ ds

                    # stress (e_rr,e_yy,e_tt)
                    self.sig_n[i, j] = self.D[0:3, 0:3] @ self.eps_n[i, j]

                    # Gauss-Legendre sum for distributed load vector
                    self.fcgs += (N.T @ np.array([self.bx, self.by]).reshape(-1, 1)) * dJ * 2 * np.pi

            # Gauss-Legendre integration (reduced)
            sr, wr = self.gl_quadrature(1)
            for i in range(len(sr)):
                for j in range(len(sr)):
                    # Jacobian of the iso-parametric mapping in the point ij
                    Jac = ElementSolid_Jac(sr[i], sr[j], self.xe).reshape((2, 2))

                    # Strain interpolation matrix
                    N = ElementSolid_N(sr[i], sr[j])

                    # Shape functions
                    phi = ElementSolid_phi(sr[i], sr[j])

                    # Density
                    rho_ij = np.dot(phi, self.xe[:, 1])

                    inv_Jac = np.linalg.inv(Jac)    
                    inv_Jac_blc = block_diag(inv_Jac, inv_Jac)

                    # Strain interpolation matrix
                    B = np.dot(np.array([0, 1, 1, 0]), inv_Jac_blc.T) @ ElementSolid_B(sr[i], sr[j])

                    # Done once per gauss point
                    dJ = np.linalg.det(Jac) * wr[i] * wr[j] * rho_ij
                    
                    if dJ < 0:
                        raise('negative determinant of the jacobian')
                        
                    # Gauss-Legendre sum for stiffness
                    self.Kgs += B.T @ B * self.D[3, 3] * dJ * 2 * np.pi

                    # strain (e_rr,e_yy,e_tt)
                    self.eps_s[i, j] = B @ ds

                    # stress (e_rr,e_yy,e_tt)
                    self.sig_s[i, j] = self.D[3, 3] * self.eps_s[i, j]
        else:
            # Gauss-Legendre full
            sf, wf = self.gl_quadrature(2)  # Assuming sf and wf are defined similarly to sr and wr
            for i in range(len(sf)):
                for j in range(len(sf)):
                    # Jacobian of the iso-parametric mapping in the point ij
                    Jac = ElementSolid_Jac(sf[i], sf[j], self.xe).reshape((2, 2))

                    # Strain interpolation matrix
                    N = ElementSolid_N(sf[i], sf[j])

                    # Shape functions
                    phi = ElementSolid_phi(sf[i], sf[j])

                    # Density
                    rho_ij = np.dot(phi, self.xe[:, 1])
                    Jac_inv = np.linalg.inv(Jac)
                    Jac_inv_blc = block_diag(Jac_inv, Jac_inv)

                    # Strain interpolation matrix
                    B = np.dot(np.array([[1, 0, 0, 0], [0, 0, 0, 1]]), Jac_inv_blc.T) @ ElementSolid_B(sf[i], sf[j])

                    # Done once per gauss point
                    dJ = np.linalg.det(Jac) * wf[i] * wf[j]
                    
                    if dJ < 0:
                        raise('negative determinant of the jacobian')                    

                    # Gauss-Legendre sum for stiffness
                    self.Kgs += B.T @ self.D[0:2, 0:2] @ B * dJ * self.h

                    # Gauss-Legendre sum for mass
                    self.Mgs += N.T @  N * self.rho * dJ * self.h

                    # strain (e_rr,e_yy,e_tt)
                    self.eps_n[i, j] = B @ ds

                    # stress (e_rr,e_yy,e_tt)
                    self.sig_n[i, j] = self.D[0:2, 0:2] @ self.eps_n[i, j]

                    # Gauss-Legendre sum for distributed load vector

                    # Perform the matrix multiplication, then reshape the result to (8, 1) before multiplying by dJ
                    self.fcgs += (N.T @ np.array([self.bx, self.by]).reshape(-1, 1)) * dJ


            # Gauss-Legendre integration (reduced)
            sr, wr = self.gl_quadrature(1)
            for i in range(len(sr)):
                for j in range(len(sr)):
                    # Jacobian of the iso-parametric mapping in the point ij
                    Jac = ElementSolid_Jac(sr[i], sr[j], self.xe).reshape((2, 2))

                    # Strain interpolation matrix
                    N = ElementSolid_N(sr[i], sr[j])

                    # Shape functions
                    phi = ElementSolid_phi(sr[i], sr[j])

                    # Density
                    rho_ij = np.dot(phi, self.xe[:, 1])
                    Jac_inv = np.linalg.inv(Jac)
                    
                    # Assuming the use of block_diag is necessary as in the full integration example
                    # If not applicable here, adjust accordingly
                    Jac_inv_blc = block_diag(Jac_inv, Jac_inv)
                    
                    # Strain interpolation matrix
                    B = np.dot(np.array([[0, 1, 1, 0]]), Jac_inv_blc.T) @ ElementSolid_B(sr[i], sr[j])

                    # Done once per gauss point
                    dJ = np.linalg.det(Jac) * wr[i] * wr[j]
                    
                    if dJ < 0:
                        raise('negative determinant of the jacobian')                    

                    # Gauss-Legendre sum for stiffness
                    self.Kgs += B.T @  B * self.D[2, 2] * dJ * self.h

                    # Before the operation, print out the shapes of N, self.rho, dJ, and self.h


                    # Gauss-Legendre sum for mass
                    # self.Mgs += N.T @ N * self.rho * dJ * self.h

                    # strain (e_rr,e_yy,e_tt)
                    self.eps_s[i, j] = B @ ds

                    # stress (e_rr,e_yy,e_tt)
                    self.sig_s[i, j] = self.D[2, 2] * self.eps_s[i, j]
        self.ftgs = np.zeros(self.fcgs.shape)
        self.ds = ds
       
    def compute_plate_pars(self, dp=None):
        
        if dp is None:
            dp = np.zeros((12, 1))
        
        self.Dbp = ElementPlate_Db(self.E, self.nu) * self.h**3 / 12
        self.Dsp = ElementPlate_Ds(self.E, self.nu) * self.h

        # Gauss-Legendre integration (full and reduced)
        sf, wf = self.gl_quadrature(2)
        sr, wr = self.gl_quadrature(1)

        self.Kb = np.zeros((12, 12))
        
        self.defb = np.empty((2, 2), dtype=object)
        self.forb = np.empty((2, 2), dtype=object)

        Bb = np.empty(ElementPlate_Bb(1, 1).shape, dtype=float)
        
        Jac = np.empty((2, 2), dtype=float)

        # Computing bending stiffness for bending and twisting
        for i in range(len(sf)):
            for j in range(len(sf)):
                Jac = ElementPlate_Jac(sf[i], sf[j], self.xe).reshape((2, 2))
                Bb = ElementPlate_Bb(sf[i], sf[j])
                
                # Blockdiagonal of Jac

                Jacblk = block_diag(Jac, Jac)

                B = np.dot(np.array([[1, 0, 0, 0], [0, 0, 0, 1], [0, 1, 1, 0]]), np.linalg.solve(Jacblk, Bb))

                dJ = np.linalg.det(Jac) * wf[i] * wf[j]
                
                if dJ < 0:
                    raise('negative determinant of the jacobian')                

                self.Kb += B.T @ self.Dbp @ B * dJ

                self.defb[i, j] = B @ dp
                self.forb[i, j] = self.Dbp @ self.defb[i, j]

        # Computing the mass stiffness matrix
        self.Mb = np.zeros((12, 12))

        N = np.empty(ElementPlate_N(1, 1).shape, dtype=float)
        Jac = np.empty((2, 2), dtype=float)

        for i in range(len(sf)):
            for j in range(len(sf)):
                Jac = ElementPlate_Jac(sf[i], sf[j], self.xe).reshape((2, 2))
                N = ElementPlate_N(sf[i], sf[j])
                dJ = np.linalg.det(Jac) * wf[i] * wf[j]

                # Create the diagonal matrix
                diagonal_matrix = np.diag([self.h, self.h**3/12, self.h**3/12])

                # Update self.Mb using the corrected formula
                self.Mb += N.T @ (self.rho * diagonal_matrix) @ N * dJ

        # Shear stiffness matrix full integration
        self.Ks2 = np.zeros((12, 12))

        Jac = np.empty((2, 2), dtype=float)
        Bs1 = np.empty(ElementPlate_Bs1(1, 1).shape, dtype=float)
        Bs2 = np.empty(ElementPlate_Bs2(1, 1).shape, dtype=float)

        for i in range(len(sf)):
            for j in range(len(sf)):
                Jac = ElementPlate_Jac(sf[i], sf[j], self.xe).reshape((2, 2))
                Bs1 = ElementPlate_Bs1(sf[i], sf[j])
                Bs2 = ElementPlate_Bs2(sf[i], sf[j])

                Bs = Bs1 + np.linalg.solve(Jac, Bs2)

                dJ = np.linalg.det(Jac) * wf[i] * wf[j]
                
                if dJ < 0:
                    raise('negative determinant of the jacobian')
                        
                self.Ks2 += Bs.T @ self.Dsp @ Bs * dJ

        # Shear stiffness matrix reduced integration
        self.Ks1 = np.zeros((12, 12))
        self.defs = np.empty((1, 1), dtype=object)
        self.fors = np.empty((1, 1), dtype=object)

        Jac = np.empty((2, 2), dtype=float)
        Bs1 = np.empty(ElementPlate_Bs1(1, 1).shape, dtype=float)
        Bs2 = np.empty(ElementPlate_Bs2(1, 1).shape, dtype=float)

        for i in range(len(sr)):
            for j in range(len(sr)):
                Jac = ElementPlate_Jac(sr[i], sr[j], self.xe).reshape((2, 2))
                Bs1 = ElementPlate_Bs1(sr[i], sr[j])
                Bs2 = ElementPlate_Bs2(sr[i], sr[j])

                Bs = Bs1 + np.linalg.solve(Jac, Bs2)

                dJ = np.linalg.det(Jac) * wr[i] * wr[j]
                
                if dJ < 0:
                    raise('negative determinant of the jacobian')
                
                self.Ks1 += Bs.T @ self.Dsp @ Bs * dJ

                self.defs[i, j] = Bs @ dp
                self.fors[i, j] = self.Dsp @ self.defs[i, j]

        # Stiffness matrix total
        # Hourglass control
        poly_area = self.polyarea(self.xe)
        self.delta = self.epsilon * self.h**2 / poly_area
        self.Ks = self.Ks1 + self.delta * (self.Ks2 - self.Ks1)
        self.Kp = self.Kb + self.Ks

        # Calculate the force vector and element matrices
        self.fcp = np.zeros((12, 1))
        N = np.empty(ElementPlate_N(1, 1).shape, dtype=float)
        Jac = np.empty((2, 2), dtype=float)

        for i in range(len(sf)):
            for j in range(len(sf)):
                Jac = ElementPlate_Jac(sf[i], sf[j], self.xe).reshape((2, 2))
                N = ElementPlate_N(sf[i], sf[j])

                dJ = np.linalg.det(Jac) * wf[i] * wf[j]
                
                if dJ < 0:
                    raise('negative determinant of the jacobian')

                self.fcp += N.T @ np.array([self.bz, 0, 0]).reshape(-1, 1) * dJ

        self.Kgp = self.Kp
        self.Mgp = self.Mb
        self.fcgp = self.fcp
        self.ftgp = np.zeros(self.fcp.shape)


    def compute_drilling_pars(self):
        k3 = np.array([
                    [ 1,   -1/2, -1/2], 
                    [-1/2,  1,   -1/2], 
                    [-1/2, -1/2,  1]
                      ])
                

        k4a = np.zeros((4, 4))
        

        poly_area_1 = self.polyarea(self.xe[[0,1,2], :])  
        poly_area_2 = self.polyarea(self.xe[[1,2,3], :])
        poly_area_3 = self.polyarea(self.xe[[0,1,3], :])
        poly_area_4 = self.polyarea(self.xe[[0,2,3], :])

        k4a[np.ix_([0, 1, 2], [0, 1, 2])] = k3 * self.h * self.E * self.alpha * poly_area_1
        k4a[np.ix_([1, 2, 3], [1, 2, 3])] = k4a[np.ix_([1, 2, 3], [1, 2, 3])]  + k3 * self.h * self.E * self.alpha * poly_area_2
        
        k3 = np.array([
                    [ 1,   -1/2, -1/2], 
                    [-1/2,  1,   -1/2], 
                    [-1/2, -1/2,  1]
                      ])

        k4b = np.zeros((4, 4))
        k4b[np.ix_([0, 2, 3], [0, 2, 3])] = k3 * self.h * self.E * self.alpha * poly_area_3
        k4b[np.ix_([0, 1, 3], [0, 1, 3])] = k4b[np.ix_([0, 1, 3], [0, 1, 3])] + k3 * self.h * self.E * self.alpha * poly_area_4
        
        self.Kd = (k4a + k4b) / 2

        self.Kgd = self.Kd
        self.fcgd = np.zeros((4, 1))
        self.ftgd = np.zeros((4, 1))
        self.Mgd = self.Kgd/1e10


    def extract_pars(self, pars):
        """
        Extract the parameters from the dictionary pars.
        """
        self.E = pars.get("E", 210e9)
        self.nu = pars.get("nu", 0.3)
        self.rho = pars.get("rho", 7850)
        self.h = pars.get("h", 5e-3)
        # node labels
        self.nodal_labels = pars.get("nodal_labels", [1, 2, 3, 4])
        # extract nodal coordinates
        self.nodal_coords = self.my_nodes.find_coords(self.nodal_labels)

        self.alpha = pars.get("alpha", 0.3)
        self.epsilon = pars.get("epsilon", 0.01)
        self.bx = pars.get("bx", 0.0)
        self.by = pars.get("by", 0.0)
        self.bz = pars.get("bz", 0.0)
        self.type = pars.get("type", "ps")  # type of analysis (ps = plane stress, pe = plane strain, ax = axisymmetric)
        self.dofs_q = pars.get("dofs_q", np.zeros((0, 2), dtype=np.int32))

    def fun_mapping(self, ind):
        Z = np.zeros((len(ind), 6))
        for i, value in enumerate(ind):
            Z[i, abs(value) - 1] = np.sign(value)
        Z = np.block([[Z, np.zeros_like(Z), np.zeros_like(Z), np.zeros_like(Z)],
                    [np.zeros_like(Z), Z, np.zeros_like(Z), np.zeros_like(Z)],
                    [np.zeros_like(Z), np.zeros_like(Z), Z, np.zeros_like(Z)],
                    [np.zeros_like(Z), np.zeros_like(Z), np.zeros_like(Z), Z]])
        return csr_array(Z)
    
    #%% Plot 3d elements
    def plot(self, ax):
        # Use nodal coordinates directly to form a quadrilateral grid
        x = self.nodal_coords[:, 0]
        y = self.nodal_coords[:, 1]
        z = self.nodal_coords[:, 2]

        # Reshape X, Y, Z into a 2x2 grid (since we have 4 points)
        X = np.array([[x[0], x[1]], [x[3], x[2]]])
        Y = np.array([[y[0], y[1]], [y[3], y[2]]])
        Z = np.array([[z[0], z[1]], [z[3], z[2]]])

        # Plot the surface with transparency (alpha)
        ax.plot_surface(X, Y, Z, color='cyan', edgecolor='black', alpha=0.5, lw=0.5)

        return ax
    
    def dump_to_paraview(self):
        # here it goes the dump_to_paraview implementation for the beam3d element
        pass