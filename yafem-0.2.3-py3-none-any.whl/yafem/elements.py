import numpy as np
import scipy as sp
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import typing
from scipy.sparse import coo_array
from yafem.nodes import nodes

#%% element class
class element:

    pars: typing.Dict
    nodal_labels : np.ndarray[np.int64]
    nodal_coords : np.ndarray[np.float64]
    dofs : np.ndarray[np.int64]
    Zu : coo_array
    Zq : coo_array
    element_type: str # tri3, quad4, line2 (use the same labelling as GMSH)

    G : np.ndarray[np.float64]
    M : np.ndarray[np.float64]
    C : np.ndarray[np.float64]
    K : np.ndarray[np.float64]
    Q : np.ndarray[np.float64]
    r : np.ndarray[np.float64] # restoring force
    u : np.ndarray[np.float64] # displacement
    v : np.ndarray[np.float64] # velocity
    a : np.ndarray[np.float64] # acceleration
    p : np.ndarray[np.float64] # internal variables (e.g., for plasticity)
    q : np.ndarray[np.float64] # temperature
    t : float # time
    i : int # step

    Ml : np.ndarray[np.float64]
    Cl : np.ndarray[np.float64]
    Kl : np.ndarray[np.float64]
    rl : np.ndarray[np.float64]
    ul : np.ndarray[np.float64]
    vl : np.ndarray[np.float64]
    al : np.ndarray[np.float64]

    my_nodes: nodes # link to the nodes of the model

    #%% class constructor
    def __init__(self, my_nodes,pars):
        pass

    #%% compute the mass matrix
    def compute_M(self):
        return self.M
    
    #%% compute the restoring force
    def compute_r(self,u,v,q,t,i):

        # compute the restoring force
        r = self.K @ u + self.C @ v

        # store the state variables
        self.u = u
        self.v = v
        self.r = r
        self.t = t 
        self.i = i

        # return the restoring force
        return r

    #%% compute the stiffness matrix
    def compute_K(self,u,v,q,t,i):
        return self.K

    #%% compute the damping matrix
    def compute_C(self,u,v,q,t,i):
        return self.C

    #%% Function for compute the collocation matrix Zu and Zq
    @jax.jit
    def collocation_indices(dof_e, dofs):

        def indices(dof_e, dofs):
            match = jnp.all(dofs == dof_e, axis=1)
            return jnp.argmax(match), jnp.any(match)
                
        idx, found = jax.vmap(lambda dof_e: indices(dof_e, dofs))(dof_e) 
        all_rows = jnp.arange(jnp.shape(found)[0])

        return idx, found, all_rows

    #%% compute the collocation matrix for displacement-controlled dofs
    def compute_Zu(self,dofs):
        
        if jnp.shape(dofs)[0] != 0:
            # idx, found = jax.vmap(lambda dof_e: element.collocation_indices(dof_e, dofs))(self.dofs)    
            idx, found, all_rows = element.collocation_indices(self.dofs, dofs)          
            rows = all_rows[found]
            cols = idx[rows]
        else:
            rows = []
            cols = []

        # Create the collocation matrix for displacement-controlled dofs
        self.Zu = coo_array((np.ones_like(rows), (rows, cols)), shape=(self.dofs.shape[0], dofs.shape[0]), dtype=np.int8).tocsr()

    #%% compute the collocation matrix for temperature-controlled dofs
    def compute_Zq(self,dofs_q):

        if jnp.shape(dofs_q)[0] != 0:
            # idx, found = jax.vmap(lambda dof_e: element.collocation_indices(dof_e, dofs))(self.dofs)    
            idx, found, all_rows = element.collocation_indices(self.dofs_q, dofs)          
            rows = all_rows[found]
            cols = idx[rows]
        else:
            rows = []
            cols = []

        # Create the collocation matrix for temperature-controlled dofs
        self.Zq = coo_array((np.ones_like(rows), (rows, cols)), shape=(self.dofs_q.shape[0], dofs_q.shape[0]), dtype=np.int8).tocsr()

    #%% reset the element state
    def reset(self):

        self.u = np.zeros(self.dofs.shape[0])
        self.v = np.zeros(self.dofs.shape[0])
        self.a = np.zeros(self.dofs.shape[0])
        self.q = np.zeros(self.dofs_q.shape[0])

    #%% plot the element
    def plot(self,ax):
        pass
    
    #%% compute element results (e.g., strain and stress)
    def compute_results(self):
        pass

    #%% save element results in paraview
    def dump_to_paraview(self):
        pass

#%% element_MCK class
class element_MCK(element):

    # class constructor
    def __init__(self, my_nodes, pars):

        # superclass constructor
        super().__init__(my_nodes,pars)

        # extract parameters and assign default values
        self.extract_pars(pars)

    #%% extract parameters and assign default values
    def extract_pars(self,pars):

        # stiffness matrix
        if 'K' in pars:
            self.K = pars['K'].astype(np.float64)
        else:
            raise Exception('the stiffness parameter must be defined')

        self.M = pars.get('M', np.zeros(self.K.shape).astype(np.float64)) # mass matrix
        self.C = pars.get('C', np.zeros(self.K.shape).astype(np.float64)) # damping matrix

        # list of dofs
        self.dofs = pars.get('dofs', np.transpose([np.arange(0, self.K.shape[0], dtype=np.int32), 
                                     np.zeros(self.K.shape[0], dtype=np.int32)])).astype(np.int32)

        # temperature controlled dofs
        self.dofs_q = pars.get('dofs_q', np.zeros((0, 2), dtype=np.int32)).astype(np.int32)

#%% element_beam2d class
class element_beam2d(element):

    # all element parameters are hidden
    _A : float # cross-section area
    _I : float # cross-section inertia
    _L : float # beam2d length
    _E : float # elastic modulus
    _Rho : float # density

    # class constructor
    def __init__(self, my_nodes, pars):

        # superclass constructor
        super().__init__(my_nodes,pars)

        # link the nodes to the element
        self.my_nodes = my_nodes

        # extract parameters and assign default values
        self.extract_pars(pars)

        # element dofs
        self.dofs = np.array([[self.nodal_labels[0],0],   #dof 0 = axial load
                              [self.nodal_labels[0],1],   #dof 1 = bending 
                              [self.nodal_labels[0],2],   #dof 2 = moment 
                              [self.nodal_labels[1],0],
                              [self.nodal_labels[1],1],
                              [self.nodal_labels[1],2]],dtype=np.int32)
        
        # no temperature dofs
        self.dofs_q = np.zeros((0,2))
        
        # rotation matrix in the xy plane
        s = (self.nodal_coords[1,:2] - self.nodal_coords[0,:2])/self._L
        t = np.array([-s[1],s[0]])
        R = np.array([s,t])

        # global to local transformation matrix in the xy plane
        self.G = sp.linalg.block_diag(R,[[1]],R,[[1]])

        # local stiffness matrix
        self.Kl = np.array([[self._E*self._A/self._L,0,0,-self._E*self._A/self._L,0,0],
                            [0,12*self._E*self._I/self._L**3,6*self._E*self._I/self._L**2,0, -12*self._E*self._I/self._L**3, 6*self._E*self._I/self._L**2],
                            [0,6*self._E*self._I/self._L**2,4*self._E*self._I/self._L,0,-6*self._E*self._I/self._L**2,2*self._E*self._I/self._L],
                            [-self._E*self._A/self._L,0,0,self._E*self._A/self._L,0,0],
                            [0,-12*self._E*self._I/self._L**3,-6*self._E*self._I/self._L**2, 0,12*self._E*self._I/self._L**3,-6*self._E*self._I/self._L**2],
                            [0,6*self._E*self._I/self._L**2,2*self._E*self._I/self._L,0,-6*self._E*self._I/self._L**2,4*self._E*self._I/self._L]],dtype=np.float64)

        # local mass matrix (TO BE ADDED LATER)
        Mn = self._A * self._L * self._Rho / 2
        In = self._A * self._L * self._Rho / 2 * self._L**2 / 3 # TO BE CHECKED !!

        # mass matrix in local coordinates
        self.Ml = np.zeros((6,6),dtype=np.float64)       
        self.Ml = np.diag(np.array([Mn,Mn,In,Mn,Mn,In]))

        # global stiffness matrix in the xy plane
        self.K = self.G.transpose() @ self.Kl @ self.G

        # global mass matrix in the xy plane
        self.M = self.G.transpose() @ self.Ml @ self.G

        # damping matrix in global coordinates
        self.C = np.zeros(self.K.shape).astype(np.float64)

    #%% extract parameters and assign default values
    def extract_pars(self,pars):

        self._A = float(pars.get('A', 1.0)) # cross-section area
        self._I = float(pars.get('I', 1.0)) # cross-section inertia
        self._E = float(pars.get('E', 1.0)) # elastic modulus
        self._Rho = float(pars.get('Rho', 1.0)) # density

        # node labels
        self.nodal_labels = pars.get('nodal_labels', np.array([0, 1], dtype=np.int32)).astype(np.int32)

        # extract nodal coordinates
        self.nodal_coords = self.my_nodes.find_coords(self.nodal_labels)

        # beam2d length
        self._L = np.linalg.norm(self.nodal_coords[1,:] - self.nodal_coords[0,:])

    #%% plot the element
    def plot(self):#,ax,ue,uscale):

        # plot the beam in 2d
        fig, ax = plt.subplots()
        ax.plot(self.nodal_coords[:, 0], self.nodal_coords[:, 1])
        plt.show()

        '''
        # Add the polygon patch to the axes
        #ax.add_patch(patches.Polygon(self.node_coord[:,0:2], color='blue', alpha=0.5))
        ax.plot(self.nodal_coord[:,0],self.nodal_coord[:,1], color='blue')

        # Update position
        pos = self.nodal_coord.copy() # be carefull !!!

        pos[0,0] = pos[0,0] + ue[0] * uscale
        pos[0,1] = pos[0,1] + ue[1] * uscale
        pos[1,0] = pos[1,0] + ue[3] * uscale
        pos[1,1] = pos[1,1] + ue[4] * uscale

        #ax.add_patch(patches.Polygon(pos[:,0:2], color='red', alpha=0.5))
        ax.plot(pos[:,0],pos[:,1], color='red')        
        '''

#%%

'''
class element_solid2d(element):

    def __init__(self, pars, node):

        super().__init__(pars)

        self.E = pars['youngs_modulus']
        self.nu = pars['poisson']        
        self.h = pars['thickness']
        self.node_ID = node[:,0].astype(int)
        self.node_coord = node[:,1:3]
        self.dof = np.array([[self.node_ID[0],0],   #dof 0 = axial load
                             [self.node_ID[0],1],   #dof 1 = bending 
                             [self.node_ID[1],0],
                             [self.node_ID[1],1],
                             [self.node_ID[2],0],   
                             [self.node_ID[2],1],   
                             [self.node_ID[3],0],
                             [self.node_ID[3],1]],dtype="int")
        disp = np.zeros((1,8))
        self.compute_K(disp) 

    def compute_K(self,disp):
        self.Ke = np.zeros((8,8))                     #element stiffness
        Ke_b = np.zeros((8,8))

        #Derivative of shape functions 
        N = lambda s, t : 1/4* np.array([[-(1-t),  (1-t), (1+t), -(1+t)],
                                         [-(1-s), -(1+s), (1+s),  (1-s)]])
        #Plane stress
        D = np.array([[self.E/(1-self.nu**2),          self.nu*self.E/(1-self.nu**2),  0],         #plane stress
                      [self.nu*self.E/(1-self.nu**2),  self.E/(1-self.nu**2),          0],
                      [0,                              0,                              self.E/(2*(1+self.nu))]])   

        #Quadrature rule (shear)
        r,w = self.GaussPoints(1)

        #Jacobian matrix [dx/ds,dx/dt;dy/ds,dy/dt]
        Jsh = N(r,r) @ self.node_coord

        Bssh = np.zeros((4,8))
        Bssh[0,[0,2,4,6]] = N(r,r)[0,:] #dphi_ds_val
        Bssh[1,[0,2,4,6]] = N(r,r)[1,:] #dphi_dt_val
        Bssh[2,[1,3,5,7]] = N(r,r)[0,:]
        Bssh[3,[1,3,5,7]] = N(r,r)[1,:]

        Bsh = np.array([[0,1,1,0]]) @ sp.linalg.block_diag(np.linalg.inv(Jsh),np.linalg.inv(Jsh)) @ Bssh

        Ke_sh = self.h * Bsh.transpose() * D[2,2]  * Bsh * np.linalg.det(Jsh) * w * w 
        
        #Quadrature rule (bending)
        r,w = self.GaussPoints(2)

        #Numerical ingration
        self.stress = np.zeros((4,3))
        n = 0
        for si,wi in zip(r,w):
            for tj,wj in zip(r,w):

                # Jacobian matrix [dx/ds,dx/dt;dy/ds,dy/dt]
                J = N(si,tj) @ self.node_coord

                Bs = np.zeros((4,8))
                Bs[0,[0,2,4,6]] = N(si,tj)[0,:] #dphi_ds_val
                Bs[1,[0,2,4,6]] = N(si,tj)[1,:] #dphi_dt_val
                Bs[2,[1,3,5,7]] = N(si,tj)[0,:]
                Bs[3,[1,3,5,7]] = N(si,tj)[1,:]

                Bb = np.array([[1,0,0,0],[0,0,0,1]]) @ sp.linalg.block_diag(np.linalg.inv(J),np.linalg.inv(J)) @ Bs

                Ke_b += self.h * Bb.transpose() @ D[0:2,0:2] @ Bb * np.linalg.det(J) * wi * wj 

                #set displacement to zero, and run again later with known displacement. calculate the stress here
                B = np.concatenate((Bb,Bsh),axis=0)
                strain = B @ disp.transpose()
                stress = D @ strain
                self.stress[n,:] = stress.transpose()
                n += 1

        self.Ke = Ke_b + Ke_sh

    def GaussPoints(self,order):
        # quadrature rules in 1D (2D rules are obtained by combining 1Ds as in a grid)
        if order == 1:
            r = 0.0
            w = 2.0 
        elif order == 2:
            r = np.array([-1/np.sqrt(3),1/np.sqrt(3)])
            w = np.array([1.0,1.0])

        return r,w
    
    def calculate_stress(self,u):
        self.compute_K(u)
    
    def plot(self,ax,ue,uscale):

        # Add the polygon patch to the axes
        ax.add_patch(patches.Polygon(self.node_coord[:,0:2],color='blue', alpha=0.5)) 

        # Update position
        self.pos = self.node_coord.copy # be carefull !!!
        
        self.pos[0,0] = self.pos[0,0] + ue[0] * uscale
        self.pos[0,1] = self.pos[0,1] + ue[1] * uscale
        self.pos[1,0] = self.pos[1,0] + ue[2] * uscale
        self.pos[1,1] = self.pos[1,1] + ue[3] * uscale
        self.pos[2,0] = self.pos[2,0] + ue[4] * uscale
        self.pos[2,1] = self.pos[2,1] + ue[5] * uscale
        self.pos[3,0] = self.pos[3,0] + ue[6] * uscale
        self.pos[3,1] = self.pos[3,1] + ue[7] * uscale

        ax.add_patch(patches.Polygon(self.pos[:,0:2],color='red', alpha=0.5))

    def plot_stress(self,ax,stress_min,stress_max,direction,u):
        self.calculate_stress(u)
        avg_stress = (self.stress[0,direction] + self.stress[1,direction] + self.stress[2,direction] + self.stress[3,direction])/4.0
        stress_norm = np.interp(avg_stress,np.array([stress_min,stress_max]),np.array([0.0,1.0]))

        ax.add_patch(patches.Polygon(self.pos[:,0:2], closed=True, edgecolor='black', facecolor=plt.cm.viridis(stress_norm)))

'''

