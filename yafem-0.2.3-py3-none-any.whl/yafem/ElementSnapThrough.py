import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from scipy.linalg import block_diag
from yafem.nodes import nodes
from yafem.elements import element
from yafem.ElementSnapThrough_func import *

class ElementSnapThrough(element):
    E = None
    A = None
    a = None
    u = None
    l = None

    #%% class constructor
    def __init__(self, my_nodes, pars):

        # superclass constructor
        super().__init__(my_nodes,pars)

        # link the nodes to the element
        self.my_nodes = my_nodes
        
        # extract parameters and assign default values
        self.extract_pars(pars)

        self.element_dofs(1)

        # initialization of matrices
        self.K = ElementSnapThrough_K(self.A, self.E, self.a, self.l, self.u)
        self.r = ElementSnapThrough_r(self.A, self.E, self.a, self.l, self.u)
        self.K0 = ElementSnapThrough_K0(self.A, self.E, self.a, self.l)
        self.r0 = ElementSnapThrough_r0(self.A, self.E, self.a, self.l)
        self.rmax = ElementSnapThrough_rmax(self.A, self.E, self.a, self.l)

    #%% extract parameters
    def extract_pars(self, pars):
        self.E            = pars.get("E", 2.1e11) # young's modulus
        self.A            = pars.get("A", 0.01) # element cross section area
        self.a            = pars.get("a", 1.0) # displacement step
        self.u            = pars.get("u", 1.0) # displacement
        self.L            = pars.get("L", 1.0) # element length
        self.nodal_labels = pars.get("nodal_labels", [1, 2])

    #%% Computing element dofs
    def element_dofs(self, dofs_per_node):

        self.dofs = np.empty([dofs_per_node*2,2],dtype=int)

        self.dofs[0:dofs_per_node,0] = self.nodal_labels[0] # Label of first node
        self.dofs[dofs_per_node:,0]  = self.nodal_labels[1] # Label of second node
        self.dofs[:,1] = np.tile(np.arange(0,dofs_per_node), 2) + 1 # Dofs of both nodes
    
        return self.dofs

    #%% Restoring force
    def compute_r(A, E, a, L, u):

        # Link to the restoring force vector
        r = ElementSnapThrough_r(A, E, a, L, u)

        return r

    #%% Tangent stiffness
    def compute_K(A, E, a, L, u):

        # Link to the restoring force vector
        K = ElementSnapThrough_K(A, E, a, L, u)

        return K
