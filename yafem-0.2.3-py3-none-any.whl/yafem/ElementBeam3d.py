import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from scipy.linalg import block_diag
from yafem.nodes import nodes
from yafem.elements import element
from yafem.ElementBeam3d_func import *

class ElementBeam3d(element):
    D1    = None
    D2    = None
    E     = None
    G1    = None
    H     = None
    L     = None
    alpha = None
    fa    = None
    fby   = None
    fbz   = None
    k0a   = None
    k0b   = None
    rho   = None
    theta = None

    #TODO: Anders, use these parameters to allow for hollow rectangular cross-sections (D1, D2 for depth and H for thickness are already there)
    shape = None # default is "circular" so all our models do not need updates; we add "rectangular"
    B1    = None
    B2    = None
    
    Ka    = None
    Kwa   = None
    Ma    = None
    fca   = None
    fta   = None
    Kby   = None
    Kbz   = None
    Kwby  = None
    Kwbz  = None
    Mby   = None
    Mbz   = None
    fcby  = None
    fcbz  = None
    Kt    = None
    Mt    = None

    #%% class constructor
    def __init__(self, my_nodes, pars):

        # superclass constructor
        super().__init__(my_nodes,pars)

        # link the nodes to the element
        self.my_nodes = my_nodes
        
        # extract parameters and assign default values
        self.extract_pars(pars)

        self.element_dofs(6)

        # Coordinate transformation matrix calculation
        r = self.nodal_coords[1] - self.nodal_coords[0]

        # Find indices of non-zero elements
        x_ind = np.nonzero(r)[0]

        # Check the value of x_ind[0] and calculate s accordingly
        if x_ind[0] == 0:
            s = np.array([-r[1], r[0], 0])
        elif x_ind[0] == 1:
            s = np.array([-r[1], r[0], 0])
        elif x_ind[0] == 2:
            s = np.array([0, 1, 0])

        # Calculate t as the cross product of r and s
        t = np.cross(r, s)

        # Normalize r, s, and t
        r = r / np.linalg.norm(r)
        s = s / np.linalg.norm(s)
        t = t / np.linalg.norm(t)

        # Local reference system
        self.T = np.array([r, s, t])
        
        # Transformation matrix for the displacement vector of a single node
        # Assuming BlockDiagonal is a placeholder for an actual block diagonal matrix construction
        # For simplicity, using np.kron (Kronecker product) to simulate block diagonal behavior
        self.G = np.kron(np.eye(4), self.T)  # Adjust based on actual BlockDiagonal implementation

        # Axial components
        Ka   = ElementBeam3d_Ka(self.L, self.E, self.D1, self.D2, self.H)
                
        Kwa  = ElementBeam3d_Kwa(self.L, self.k0a)  
         
        Ma   = ElementBeam3d_Ma(self.L, self.D1, self.D2, self.H, self.rho)   
        fca  = ElementBeam3d_fca(self.L, self.fa) 
        fta  = ElementBeam3d_fta(self.L, self.E, self.alpha, self.theta, self.D1, self.D2, self.H)
        
        # Lateral components y
        Kby  = ElementBeam3d_Kby(self.L, self.E, self.D1, self.D2, self.H)  
        Kwby = ElementBeam3d_Kwby(self.L, self.k0b)    
        Mby  = ElementBeam3d_Mby(self.L, self.D1, self.D2, self.H, self.rho)  
        fcby = ElementBeam3d_fcby(self.L, self.fby)   
        
        # Lateral components z
        Kbz  = ElementBeam3d_Kbz(self.L, self.E, self.D1, self.D2, self.H)  
        Kwbz = ElementBeam3d_Kwbz(self.L, self.k0b)
        Mbz  = ElementBeam3d_Mbz(self.L, self.D1, self.D2, self.H, self.rho)  
        fcbz = ElementBeam3d_fcbz(self.L, self.fbz)
        
        # Torsional components
        Kt   = ElementBeam3d_Kt(self.L, self.G1, self.D1, self.D2, self.H) 
        Mt   = ElementBeam3d_Mt(self.L, self.D1, self.D2, self.H, self.rho)
        
        # Indexes for stiffness assembly
        inda  = [0, 6]  # Indices for axial properties, adjusted for Python indexing
        indbz = [2, 4, 8, 10]  # Indices for lateral properties z, adjusted for Python indexing
        indby = [1, 5, 7, 11]  # Indices for lateral properties y, adjusted for Python indexing
        indt  = [3, 9]  # Indices for torsional properties, adjusted for Python indexing

        # Stiffness matrix in local coordinate system
        self.Kl = np.zeros((12, 12))
        self.Ml = np.zeros((12, 12))
        self.rl = np.zeros((12, 1))

        #%% Axial properties
        # Combined axial rod + winkler
        self.Kl[np.ix_(inda, inda)] += Ka + Kwa

        # Axial mass matrix
        self.Ml[np.ix_(inda, inda)] += Ma

        # Mechanical and Thermal load vector
        self.rl[inda] += (fca + fta)

        #%% Lateral properties
        # Lateral stiffness
        self.Kl[np.ix_(indby, indby)] += Kby + Kwby
        self.Kl[np.ix_(indbz, indbz)] += Kbz + Kwbz

        # Lateral mass matrix
        self.Ml[np.ix_(indby, indby)] += Mby
        self.Ml[np.ix_(indbz, indbz)] += Mbz

        # Mechanical and Thermal load vector
        self.rl[indby] += fcby
        self.rl[indbz] += fcbz

        #%% Torsional properties
        # Stiffness
        self.Kl[np.ix_(indt, indt)] += Kt

        # Mass
        self.Ml[np.ix_(indt, indt)] += Mt

        #%% Global reference

        # Stiffness matrix in global coordinate system
        self.K = self.G.T @ self.Kl @ self.G
        self.M = self.G.T @ self.Ml @ self.G

        # damping matrix in global coordinates
        self.C = np.zeros_like(self.K)

        # local to global coordinate transformation
        self.r = self.G.T @ self.rl     
 
        self.Ka   = Ka
        self.Kwa  = Kwa
        self.Ma   = Ma
        self.fca  = fca
        self.fta  = fta
        self.Kby  = Kby
        self.Kbz  = Kbz
        self.Kwby = Kwby
        self.Kwbz = Kwbz
        self.Mby  = Mby
        self.Mbz  = Mbz
        self.fcby = fcby
        self.fcbz = fcbz
        self.Kt   = Kt
        self.Mt   = Mt

    #%% extract parameters
    def extract_pars(self, pars):
        self.D1    = pars.get("D1", 20.0) # Outer diameter of pipe in firste node
        self.D2    = pars.get("D2", 20.0) # Outer diameter of pipe in second node
        self.H     = pars.get("H", 2) # thickness of pipe in both ends
        self.E     = pars.get("E", 210e3) # Youngs modulus
        self.G1    = pars.get("G", 81e3) # Shear modulus
        self.k0a   = pars.get("k0a", 0.0) # Axial Winkler stiffness
        self.k0b   = pars.get("k0b", 0.0) # Lateral Winkler stiffness
        self.rho   = pars.get("rho", 7850/1e9) # Density
        self.fa    = pars.get("fa", 0.0) # Axial element destributed force
        self.fby   = pars.get("fby", 0.0) # Lateral element destributed force in y-direction
        self.fbz   = pars.get("fbz", 0.0) # Lateral element destributed force in z-direction
        self.alpha = pars.get("alpha", 0.0) # coefficient of thermal expansion 
        self.theta = pars.get("theta", 0.0) # Thermal loading
        self.nodal_labels = pars.get("nodal_labels", [1, 2])
        
        # extract nodal coordinates
        self.nodal_coords = self.my_nodes.find_coords(self.nodal_labels)
        self.L = np.linalg.norm(self.nodal_coords[1] - self.nodal_coords[0])
    
        # temperature controlled dofs
        self.dofs_q = np.array(pars.get("dofs_q", []), dtype=np.int32).reshape(-1, 2) if "dofs_q" in pars else np.zeros((0, 2), dtype=np.int32)
    
    #    self.nu    = pars.get("nu", 0.3)
    #    self.J     = pars.get("J", 1.0)
    
    #%% Computing element dofs
    def element_dofs(self, dofs_per_node):

        self.dofs = np.empty([dofs_per_node*2,2],dtype=int)

        self.dofs[0:dofs_per_node,0] = self.nodal_labels[0] # Label of first node
        self.dofs[dofs_per_node:,0]  = self.nodal_labels[1] # Label of second node
        self.dofs[:,1] = np.tile(np.arange(0,dofs_per_node), 2) + 1 # Dofs of both nodes
    
        return self.dofs

    #%% Plot 3d elements
    def plot(self,ax):

        ax.plot(self.nodal_coords[:, 0], self.nodal_coords[:, 1], self.nodal_coords[:, 2], 'k-', linewidth=1)
        
        return ax  # Return the same axis object
    
    def dump_to_paraview(self):
        # here it goes the dump_to_paraview implementation for the beam3d element
        pass
