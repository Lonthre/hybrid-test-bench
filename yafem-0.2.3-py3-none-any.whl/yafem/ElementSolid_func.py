import numpy 

def ElementSolid_phi(s, t):
    return [(1/4)*(s - 1)*(t - 1), -1/4*(s + 1)*(t - 1), (1/4)*(s + 1)*(t + 1), -1/4*(s - 1)*(t + 1)]

def ElementSolid_dphis(s, t):
    return [(1/4)*t - 1/4, 1/4 - 1/4*t, (1/4)*t + 1/4, -1/4*t - 1/4]

def ElementSolid_dphit(s, t):
    return [(1/4)*s - 1/4, -1/4*s - 1/4, (1/4)*s + 1/4, 1/4 - 1/4*s]

def ElementSolid_N(s, t):
    return numpy.array([[(1/4)*(s - 1)*(t - 1), 0, -1/4*(s + 1)*(t - 1), 0, (1/4)*(s + 1)*(t + 1), 0, -1/4*(s - 1)*(t + 1), 0], [0, (1/4)*(s - 1)*(t - 1), 0, -1/4*(s + 1)*(t - 1), 0, (1/4)*(s + 1)*(t + 1), 0, -1/4*(s - 1)*(t + 1)]])

def ElementSolid_B(s, t):
    return numpy.array([[(1/4)*t - 1/4, 0, 1/4 - 1/4*t, 0, (1/4)*t + 1/4, 0, -1/4*t - 1/4, 0], [(1/4)*s - 1/4, 0, -1/4*s - 1/4, 0, (1/4)*s + 1/4, 0, 1/4 - 1/4*s, 0], [0, (1/4)*t - 1/4, 0, 1/4 - 1/4*t, 0, (1/4)*t + 1/4, 0, -1/4*t - 1/4], [0, (1/4)*s - 1/4, 0, -1/4*s - 1/4, 0, (1/4)*s + 1/4, 0, 1/4 - 1/4*s]])

def ElementSolid_G(E, nu):
    return (1/2)*E/(nu + 1)

def ElementSolid_C(E, nu):
    return numpy.array([[E**(-1.0), -nu/E, -nu/E, 0, 0, 0], [-nu/E, E**(-1.0), -nu/E, 0, 0, 0], [-nu/E, -nu/E, E**(-1.0), 0, 0, 0], [0, 0, 0, 2*(nu + 1)/E, 0, 0], [0, 0, 0, 0, 2*(nu + 1)/E, 0], [0, 0, 0, 0, 0, 2*(nu + 1)/E]])

def ElementSolid_D(E, nu):
    return numpy.array([[E*(nu - 1)/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), 0, 0, 0], [-E*nu/(2*nu**2 + nu - 1), E*(nu - 1)/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), 0, 0, 0], [-E*nu/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), E*(nu - 1)/(2*nu**2 + nu - 1), 0, 0, 0], [0, 0, 0, (1/2)*E/(nu + 1), 0, 0], [0, 0, 0, 0, (1/2)*E/(nu + 1), 0], [0, 0, 0, 0, 0, (1/2)*E/(nu + 1)]])

def ElementSolid_Dax(E, nu):
    return numpy.array([[E*(nu - 1)/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), 0], [-E*nu/(2*nu**2 + nu - 1), E*(nu - 1)/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), 0], [-E*nu/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), E*(nu - 1)/(2*nu**2 + nu - 1), 0], [0, 0, 0, (1/2)*E/(nu + 1)]])

def ElementSolid_Dpe(E, nu):
    return numpy.array([[E*(nu - 1)/(2*nu**2 + nu - 1), -E*nu/(2*nu**2 + nu - 1), 0], [-E*nu/(2*nu**2 + nu - 1), E*(nu - 1)/(2*nu**2 + nu - 1), 0], [0, 0, (1/2)*E/(nu + 1)]])

def ElementSolid_Dps(E, nu):
    return numpy.array([[-E/(nu**2 - 1), -E*nu/(nu**2 - 1), 0], [-E*nu/(nu**2 - 1), -E/(nu**2 - 1), 0], [0, 0, (1/2)*E/(nu + 1)]])

def ElementSolid_Jac(s, t, xe):
    return numpy.array([[(xe[:, :1].T).dot(numpy.array([[(1/4)*t - 1/4], [1/4 - 1/4*t], [(1/4)*t + 1/4], [-1/4*t - 1/4]])), (xe[:, 1:].T).dot(numpy.array([[(1/4)*t - 1/4], [1/4 - 1/4*t], [(1/4)*t + 1/4], [-1/4*t - 1/4]]))], [(xe[:, :1].T).dot(numpy.array([[(1/4)*s - 1/4], [-1/4*s - 1/4], [(1/4)*s + 1/4], [1/4 - 1/4*s]])), (xe[:, 1:].T).dot(numpy.array([[(1/4)*s - 1/4], [-1/4*s - 1/4], [(1/4)*s + 1/4], [1/4 - 1/4*s]]))]])

